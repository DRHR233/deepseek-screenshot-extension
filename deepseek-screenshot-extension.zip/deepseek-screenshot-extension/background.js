// background.js — Service Worker (Manifest V3)
//
// 流程：
//   1) 监听悬浮球发来的 "capture-and-ask" 消息
//   2) chrome.tabs.captureVisibleTab 截取当前可见区域
//   3) 若当前标签页不是 DeepSeek，则在后台新开 https://chat.deepseek.com 并等待就绪
//      （不打断用户当前页面，答案回传到原页面悬浮球）
//   4) 把截图 data URL + “只回答答案”提示词转发给 content-deepseek.js，由其自动粘贴并直接发送
//   5) 收到流式回复后回传给发起截图的标签页
//
// ⚠️ 关于 activeTab：
//   captureVisibleTab 需要 activeTab 权限“已生效”。activeTab 是在用户“调用扩展”
//   （点击工具栏图标 / 右键菜单 / 快捷键）时授予当前活动标签页的临时权限；
//   仅点击页面里的悬浮球本身并不会授予 activeTab。
//   因此：若悬浮球截图报权限错误，点一下工具栏图标即可（该点击会授予 activeTab）。
//   想要更稳可把 "<all_urls>" 追加到 manifest 的 host_permissions（会失去“最小权限”的初衷）。
//
// 工具栏图标 = 启用 / 停用开关（chrome.action.onClicked）：
//   启用时：正常图标，点一下即停用（badge 显示 OFF，悬浮球在各页面消失）
//   停用时：badge 显示 OFF，再点一下重新启用（悬浮球恢复）
//   状态存在 chrome.storage.local 的 "dsh_enabled"（缺省视为启用）。
//
"use strict";

// 发送给 DeepSeek 的提示词（默认值）。要改默认风格，改这一段即可。
// 用户在悬浮球里改过的提示词存在 chrome.storage.local 的 "dsh_prompt"，
// 有自定义值就优先用它（见 getPromptText()）。
// 结构：①输出格式（只要答案，字数受控）②回答风格 ③按题型处理 ④排版要求 ⑤图片引出语
const PROMPT_PREFIX =
  // ① 输出格式：只给答案，不要理由/解释
  "请直接给出结论/答案，不要解释过程，不要给理由，整体控制在 100 字以内。" +
  // ② 回答风格（精简、不啰嗦、不编造）
  "不铺垫、不客套、不重复、不绕弯；能一句话说清就一句话；" +
  "信息不足就直接说缺什么，不要编造；不要模棱两可。" +
  // ③ 按题型处理（选择题必须给全选项）
  "若是选择题，直接回答应选哪个选项，多选题请把应选的所有选项都完整列出；" +
  "若是问答题，直接回答答案内容。" +
  // ④ 排版：每个答案独占一行，方便悬浮球按行回看
  "排版要求：每个答案单独占一行（如“1.A”“2.B”各占一行），不要把多个答案合并成一段。" +
  // ⑤ 图片引出语
  "以下是图片内容，请直接给出答案：";

// 兜底超时：仅作为“驱动脚本完全无响应/崩溃”时的最后保险。
// 真正的 30s 用户级超时由 content-deepseek.js 的 REPLY_TIMEOUT_MS 负责，
// 且它是在“找输入框→贴图→填词→发送”这些前置步骤之后才开始计时的。
// 若这里仍用 30s，会与驱动脚本的总耗时竞争，出现“答案已生成却仍报发送超时”。
// 自翻页模式最多 20 张、逐张上传（每张 ~2s）+ 生成，最坏要一分多钟，故留 150s。
const REQUEST_TIMEOUT_MS = 150000; // 保险超时：150 秒
const DEEPSEEK_ORIGIN = "https://chat.deepseek.com";

// ---------- 提示词：读取 / 保存 / 恢复默认 ----------
// 用户可在悬浮球里查看并修改提示词，修改后的文本存 chrome.storage.local，
// 发送时优先使用它；没有自定义值时才用 PROMPT_PREFIX。
const PROMPT_KEY = "dsh_prompt";

function getDefaultPrompt() {
  return PROMPT_PREFIX;
}

async function getPromptText() {
  try {
    const d = await chrome.storage.local.get(PROMPT_KEY);
    const saved = d && d[PROMPT_KEY];
    if (typeof saved === "string" && saved.trim()) return saved;
  } catch (e) { /* 读不到就用默认值 */ }
  return getDefaultPrompt();
}

async function savePromptText(text) {
  const t = typeof text === "string" ? text : "";
  if (!t.trim()) {
    // 空内容视为“恢复默认”
    await chrome.storage.local.remove(PROMPT_KEY);
    return getDefaultPrompt();
  }
  await chrome.storage.local.set({ [PROMPT_KEY]: t });
  return t;
}

async function resetPromptText() {
  try { await chrome.storage.local.remove(PROMPT_KEY); } catch (e) { /* 忽略 */ }
  return getDefaultPrompt();
}

// 提速：驱动脚本文件名（复用已打开的 DeepSeek 页时，可用 scripting 直接补齐注入，
// 省掉整页加载的时间）
const DRIVER_FILE = "content-deepseek.js";
const DRIVER_POLL_MS = 150;      // 探测驱动就绪的轮询间隔（越小越快开工）
const DRIVER_READY_MS = 30000;   // 驱动就绪的最长等待

// 截图参数：jpeg 比 png 小得多，上传/解码更快（纯文字截图质量 88 足够清晰）。
// 若需要无损 PNG，把 format 改回 "png" 并去掉 quality 即可。
const CAPTURE_OPTIONS = { format: "jpeg", quality: 88 };

// 一次最多 20 张：连续截图上限 10 张，自翻页模式（逐屏下滑）上限 20 张，
// 统一按 20 校验（悬浮球与驱动都按这个上限）
const MAX_BATCH_IMAGES = 20;

// requestId -> { originTabId }
// service worker 可能被回收；单次请求周期较短，用内存 Map 即可满足需求。
const pendingRequests = new Map();
let seq = 0;

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

// ---------- 启用 / 停用（点工具栏图标切换）----------
// 状态存在 chrome.storage.local 的 dsh_enabled（true=启用）。
// 为什么还要 extEnabled 这个内存缓存：onMessage 处理器是同步的，不能在里面 await，
// 所以把状态读进内存，启动时/切换时刷新；悬浮球则通过 storage.onChanged 同步显隐。
const ENABLED_KEY = "dsh_enabled";
let extEnabled = true;

function actionTitle(on) {
  return on
    ? "DeepSeek 截图提问助手（已启用，点击停用）"
    : "DeepSeek 截图提问助手（已停用，点击启用）";
}

function applyActionUi(on) {
  try {
    chrome.action.setBadgeText({ text: on ? "" : "OFF" });
    chrome.action.setBadgeBackgroundColor({ color: "#9aa3af" });
    chrome.action.setTitle({ title: actionTitle(on) });
  } catch (e) { /* action API 不可用时忽略 */ }
}

async function loadEnabled() {
  try {
    const d = await chrome.storage.local.get(ENABLED_KEY);
    extEnabled = !d || d[ENABLED_KEY] !== false;
  } catch (e) {
    extEnabled = true;
  }
  applyActionUi(extEnabled);
  return extEnabled;
}

async function setEnabled(on) {
  extEnabled = !!on;
  try {
    await chrome.storage.local.set({ [ENABLED_KEY]: extEnabled });
  } catch (e) { /* 存储失败也保持内存状态 */ }
  applyActionUi(extEnabled);
  return extEnabled;
}

// 需要扩展处于“启用”状态才会执行的消息类型
const ACTION_MESSAGE_TYPES = new Set([
  "capture-and-ask",
  "capture-only",
  "ask",
  "resend-last",
  "reread-answer",
  "prewarm"
]);

const DISABLED_TIP = "扩展已停用，点击工具栏上的扩展图标即可重新启用";

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || !message.type) return;

  // 悬浮球初始化时查询当前启用状态（缓存未刷新也能拿到准确值）
  if (message.type === "get-enabled") {
    loadEnabled().then((on) => sendResponse({ ok: true, enabled: on }));
    return true;
  }

  // 提示词：读取 / 保存 / 恢复默认（这些不受“停用”限制，随时可改）
  if (message.type === "get-prompt") {
    getPromptText().then((text) =>
      sendResponse({ ok: true, text, defaultText: getDefaultPrompt() })
    );
    return true;
  }
  if (message.type === "save-prompt") {
    savePromptText(message.text).then((text) => sendResponse({ ok: true, text }));
    return true;
  }
  if (message.type === "reset-prompt") {
    resetPromptText().then((text) => sendResponse({ ok: true, text }));
    return true;
  }

  // 已停用：所有“干活”的消息一律拒绝，只回一句提示
  if (!extEnabled && ACTION_MESSAGE_TYPES.has(message.type)) {
    sendResponse({ ok: false, disabled: true, error: DISABLED_TIP });
    return;
  }

  // 立即回答模式：截图 + 直接提问（一步到位）
  if (message.type === "capture-and-ask") {
    const originTabId = sender.tab && sender.tab.id;
    const windowId = sender.tab && sender.tab.windowId;
    if (originTabId == null || windowId == null) {
      sendResponse({ ok: false, error: "无法确定发起标签页" });
      return;
    }
    // 先截图，成功就立刻回 ok（悬浮球随即显示“等待回答…”），
    // 后续发送/收答案在后台继续跑，结果通过 answer / answer-progress 推给悬浮球
    captureImage(windowId)
      .then((url) => {
        sendResponse({ ok: true });
        startAsk(originTabId, [url]);
      })
      .catch((e) =>
        sendResponse({ ok: false, error: "截图失败，请重试（" + (e.message || e) + "）" })
      );
    return true; // 保持消息通道，异步响应
  }

  // 连续截图模式第一步：只截图，立刻把 data URL 交回悬浮球暂存
  if (message.type === "capture-only") {
    const windowId = sender.tab && sender.tab.windowId;
    if (windowId == null) {
      sendResponse({ ok: false, error: "无法确定发起标签页" });
      return;
    }
    captureImage(windowId)
      .then((url) => sendResponse({ ok: true, imageDataUrl: url }))
      .catch((e) => sendResponse({ ok: false, error: "截图失败，请重试（" + (e.message || e) + "）" }));
    return true;
  }

  // 连续截图模式第二步：把暂存的整批截图交给 DeepSeek（一次提问，图片逐张上传）
  if (message.type === "ask") {
    const originTabId = sender.tab && sender.tab.id;
    if (originTabId == null) {
      sendResponse({ ok: false, error: "无法确定发起标签页" });
      return;
    }
    const images = normalizeImages(message.images);
    if (!images.length) {
      sendResponse({ ok: false, error: "没有可发送的截图" });
      return;
    }
    // 立刻回 ok（悬浮球清空暂存、显示“已发送”），上传与提问在后台继续跑，
    // 进度与最终答案通过 answer-progress / answer 推给悬浮球
    sendResponse({ ok: true, count: images.length });
    startAsk(originTabId, images);
    return;
  }

  // 重新读取答案：超时后页面上其实可能已经有答案了，直接去读一次（不重新发送）
  if (message.type === "reread-answer") {
    const originTabId = sender.tab && sender.tab.id;
    if (originTabId == null) {
      sendResponse({ ok: false, error: "无法确定发起标签页" });
      return;
    }
    rereadAnswer(originTabId)
      .then((res) => sendResponse(res))
      .catch((e) => sendResponse({ ok: false, error: (e && e.message) || "读取答案失败" }));
    return true;
  }

  // 重新上传：把“刚刚上传过的图片”原样再发一次（不重新截图）
  if (message.type === "resend-last") {
    const originTabId = sender.tab && sender.tab.id;
    if (originTabId == null) {
      sendResponse({ ok: false, error: "无法确定发起标签页" });
      return;
    }
    loadLastImages()
      .then((list) => {
        if (!list.length) {
          sendResponse({ ok: false, error: "没有可重新上传的图片，请先截图" });
          return;
        }
        sendResponse({ ok: true, count: list.length });
        startAsk(originTabId, list); // 注意：startAsk 会再次覆盖暂存，内容相同不影响
      })
      .catch((e) => sendResponse({ ok: false, error: (e && e.message) || "重新上传失败" }));
    return true;
  }

  // 查询暂存状态（面板打开时用来显示「🔁 重新上传（n 张）」）
  if (message.type === "resend-info") {
    loadLastImages()
      .then((list) => sendResponse({ ok: true, count: list.length }))
      .catch(() => sendResponse({ ok: false, count: 0 }));
    return true;
  }

  // 清空暂存
  if (message.type === "resend-clear") {
    clearLastImages()
      .then(() => sendResponse({ ok: true, count: 0 }))
      .catch(() => sendResponse({ ok: false, count: 0 }));
    return true;
  }

  // 预热：面板打开时先把后台 DeepSeek 标签页备好，点截图时几乎不用等
  if (message.type === "prewarm") {
    const originTabId = sender.tab && sender.tab.id;
    prewarmWorkerTab(originTabId)
      .then(() => sendResponse({ ok: true }))
      .catch(() => sendResponse({ ok: false }));
    return true;
  }

  // 流式输出过程中的增量文本：只转发给悬浮球做“边生成边显示”，
  // 不结束请求（pendingRequests 保留，等最终 answer/error）。
  if (message.type === "answer-progress") {
    const req = pendingRequests.get(message.requestId);
    if (!req) return;
    chrome.tabs
      .sendMessage(req.originTabId, {
        type: "answer-progress",
        requestId: message.requestId,
        text: message.text || "",
        index: req.index,   // 兼容旧字段
        total: req.total    // 本批截图张数
      })
      .catch(() => {});
    return; // 同步返回，无需 sendResponse
  }

  if (message.type === "answer" || message.type === "error") {
    const req = pendingRequests.get(message.requestId);
    if (!req) return;
    pendingRequests.delete(message.requestId);

    // 走 askWithImages 的请求（onAnswer 已注册）：交给它的 Promise 收尾，
    // 由调用方统一回传悬浮球，这里不再直接转发
    if (typeof req.onAnswer === "function") {
      req.onAnswer({
        ok: message.type === "answer",
        text: message.text || "",
        error: message.error || ""
      });
      return;
    }

    if (req.release) req.release(); // 解除该标签页的“忙碌”标记
    chrome.tabs
      .sendMessage(req.originTabId, {
        type: message.type,
        requestId: message.requestId,
        text: message.text || "",
        error: message.error || ""
      })
      .catch(() => {});
  }
});

// 只截图，不提问（连续截图模式用；jpeg 体积小、传输快）
async function captureImage(windowId) {
  return await chrome.tabs.captureVisibleTab(windowId, CAPTURE_OPTIONS);
}

// 归一化图片数组：过滤空值、限制一次最多 MAX_BATCH_IMAGES 张
function normalizeImages(images) {
  if (!Array.isArray(images)) {
    if (typeof images === "string" && images) return [images];
    return [];
  }
  return images
    .filter((u) => typeof u === "string" && u.startsWith("data:image"))
    .slice(0, MAX_BATCH_IMAGES);
}

// 预热：面板一打开就把后台 DeepSeek 标签页备好（用户还在选截图区域时已就绪）
async function prewarmWorkerTab(originTabId) {
  const worker = await getWorkerTab();
  if (worker != null) return worker;
  let url = "";
  try {
    const t = await chrome.tabs.get(originTabId);
    url = (t && t.url) || "";
  } catch (e) { /* 忽略 */ }
  const info = await resolveTargetTab(originTabId, url);
  void info;
  return info.tabId;
}

// ---------- 提问核心：一批截图 = 一个问题，只提交一次 ----------
// 图片由 content-deepseek.js **逐张**上传到同一个输入框（每次只传 1 张、逐张累加），
// 全部传完再**只发送一次**提问。不是每张图各问一轮。
function startAsk(originTabId, images) {
  const list = normalizeImages(images);
  // 暂存“刚刚上传的图片”，供面板上的「🔁 重新上传」按钮一键再发一次
  saveLastImages(list);
  askWithImages(originTabId, list).catch((e) => {
    notifyFloat(originTabId, { type: "error", error: (e && e.message) || "发送失败" });
  });
}

// ---------- 最近一次上传的图片（重新上传用）----------
// 存 chrome.storage.session：MV3 的 service worker 被回收后内存会清空，
// 而 session 存储在浏览器会话期间一直有效（关浏览器才清），关掉/重开浏览器后需要重新截图。
// 万一超出配额（10MB），退回纯内存保存，功能仍然可用，只是 worker 被回收后失效。
const LAST_IMAGES_KEY = "dsh_last_images";
const SESSION_BUDGET_BYTES = 8 * 1024 * 1024; // 留 2MB 余量给配额
let lastImagesMemory = [];

function approxBytes(images) {
  let n = 0;
  for (const s of images) n += (s || "").length;
  return n;
}

function saveLastImages(images) {
  const list = normalizeImages(images);
  lastImagesMemory = list;
  if (!list.length) return;
  // 超出预算就只保留最后能放下的几张（越靠后越可能是用户最想要的那批）
  let keep = list;
  while (keep.length > 1 && approxBytes(keep) > SESSION_BUDGET_BYTES) {
    keep = keep.slice(1);
  }
  lastImagesMemory = keep;
  try {
    const p = chrome.storage.session.set({ [LAST_IMAGES_KEY]: keep });
    if (p && p.catch) p.catch(() => {});
  } catch (e) { /* 退化为内存暂存 */ }
}

async function loadLastImages() {
  try {
    const d = await chrome.storage.session.get(LAST_IMAGES_KEY);
    const list = normalizeImages(d && d[LAST_IMAGES_KEY]);
    if (list.length) return list;
  } catch (e) { /* 忽略 */ }
  return normalizeImages(lastImagesMemory);
}

async function clearLastImages() {
  lastImagesMemory = [];
  try { await chrome.storage.session.remove(LAST_IMAGES_KEY); } catch (e) {}
}

function notifyFloat(tabId, payload) {
  chrome.tabs.sendMessage(tabId, payload).catch(() => {});
}

// ---------- 重新读取答案（超时后补救）----------
// 记录“哪个发起页最近一次把问题发到了哪个标签页”，超时后据此回去读答案。
// 只存在内存里：worker 被回收就失效，此时会退回按域名猜（见 rereadAnswer）。
const answerTabs = new Map(); // originTabId -> targetTabId

async function resolveAnswerTab(originTabId) {
  // 1) 上次真正提交问题的标签页
  const remembered = answerTabs.get(originTabId);
  if (remembered != null) {
    try {
      const tab = await chrome.tabs.get(remembered);
      if (tab && !tab.discarded && (tab.url || "").startsWith(DEEPSEEK_ORIGIN)) return remembered;
    } catch (e) { /* 已关闭，继续猜 */ }
  }
  // 2) 发起页自己就是 DeepSeek 页面
  try {
    const originTab = await chrome.tabs.get(originTabId);
    if (originTab && (originTab.url || "").startsWith(DEEPSEEK_ORIGIN)) return originTabId;
  } catch (e) { /* 忽略 */ }
  // 3) 扩展自己的后台专用标签页
  const worker = await getWorkerTab();
  if (worker != null) {
    answerTabs.set(originTabId, worker);
    return worker;
  }
  return null;
}

async function rereadAnswer(originTabId) {
  const tabId = await resolveAnswerTab(originTabId);
  if (tabId == null) {
    return { ok: false, error: "找不到之前提问的 DeepSeek 页面，可能已被关闭" };
  }
  if (!(await ensureDriver(tabId)) && !(await waitForDriver(tabId, 8000))) {
    return { ok: false, error: "DeepSeek 页面还没准备好，请稍后重试" };
  }
  let res;
  try {
    res = await chrome.tabs.sendMessage(tabId, { type: "read-last-answer" });
  } catch (e) {
    return { ok: false, error: "读取答案失败（" + ((e && e.message) || e) + "）" };
  }
  if (!res || !res.ok) {
    return { ok: false, error: (res && res.error) || "页面上还没有答案" };
  }
  const text = (res.text || "").trim();
  if (!text) return { ok: false, error: "页面上还没有答案" };
  return { ok: true, text };
}

// 上传多张图 + 等答案可能持续一两分钟（逐张上传 + 流式生成），
// 而 MV3 service worker 空闲 30 秒就会被回收（会丢掉 pendingRequests 和进行中的请求）。
// 期间每 20 秒调一次扩展 API，把 worker 的 idle 计时重置掉。
let keepAliveTimer = null;
function startKeepAlive() {
  if (keepAliveTimer) return;
  keepAliveTimer = setInterval(() => {
    try {
      chrome.runtime.getPlatformInfo().catch(() => {});
    } catch (e) { /* 忽略 */ }
  }, 20000);
}
function stopKeepAlive() {
  if (!keepAliveTimer) return;
  clearInterval(keepAliveTimer);
  keepAliveTimer = null;
}

// 把一批截图交给 DeepSeek：**只提交一次**，由驱动脚本把图**逐张**上传到同一个
// 输入框（每次只传 1 张、逐张累加），最后只发送一次提问。
// 多张图属于同一个问题、答案只有一份；不是每张图各问一轮。
async function askWithImages(originTabId, images) {
  const list = normalizeImages(images);
  if (!list.length) {
    notifyFloat(originTabId, { type: "error", error: "没有可发送的截图" });
    return;
  }

  // 1) 确定目标标签页（并确保驱动脚本就绪）
  //    - 当前页就是 DeepSeek：直接用它
  //    - 扩展自己的后台标签页已存在：直接复用（省掉整页加载，明显更快）
  //    - 都没有：后台新开一个（active:false），只等驱动就绪，不等整页 load 完成
  let targetTabId;
  let freshChat = false;
  try {
    const originTab = await chrome.tabs.get(originTabId);
    const info = await resolveTargetTab(originTabId, originTab && originTab.url);
    targetTabId = info.tabId;
    freshChat = info.reused;
    // 记下“这轮问题发到了哪个标签页”，超时后重新读取答案要用
    answerTabs.set(originTabId, targetTabId);
  } catch (e) {
    notifyFloat(originTabId, { type: "error", error: "打开 DeepSeek 页面失败" });
    return;
  }

  // 2) 等上一次请求结束，然后占用该标签页（一批截图算一次占用）
  await waitTabIdle(targetTabId, 60000);
  const release = markTabBusy(targetTabId);

  try {
    startKeepAlive();
    const res = await submitImages(targetTabId, originTabId, list, { freshChat });
    if (res.ok && res.text) {
      notifyFloat(originTabId, { type: "answer", text: res.text });
    } else {
      notifyFloat(originTabId, { type: "error", error: res.error || "没有拿到答案" });
    }
  } finally {
    stopKeepAlive();
    release();
  }
}

// 提交一批截图并等待这一批的答案（驱动内部逐张上传、最后只发一次提问）
async function submitImages(targetTabId, originTabId, images, opts) {
  // 提示词可能被用户在悬浮球里改过，发之前取一次当前值
  const promptText = await getPromptText();
  return new Promise((resolve) => {
    const requestId = "r" + ++seq + "-" + Date.now();
    let settled = false;
    let timer = null;

    const finish = (payload) => {
      if (settled) return;
      settled = true;
      pendingRequests.delete(requestId);
      if (timer) clearTimeout(timer);
      resolve(payload);
    };

    pendingRequests.set(requestId, {
      originTabId,
      total: images.length,
      // answer/error 分支见到 onAnswer 就交给这里收集，不直接推给悬浮球
      onAnswer: (res) => finish({ ok: res.ok, text: res.text, error: res.error })
    });

    // 兜底超时（驱动彻底挂死时才会用到）
    timer = setTimeout(() => finish({ ok: false, error: "发送超时" }), REQUEST_TIMEOUT_MS);

    chrome.tabs
      .sendMessage(targetTabId, {
        type: "submit",
        requestId,
        images,                 // 一次提交整批；图片由驱动逐张上传到同一个输入框
        imageDataUrl: images[0], // 兼容旧字段（单图）
        prompt: promptText,
        freshChat: opts.freshChat
      })
      .catch(() => finish({ ok: false, error: "无法与 DeepSeek 驱动脚本通信" }));
  });
}

// ---------- 驱动就绪 / 标签页复用（提速核心）----------

// 探测驱动脚本是否已在标签页里
async function pingDriver(tabId) {
  try {
    const res = await chrome.tabs.sendMessage(tabId, { type: "ping" });
    return !!(res && res.pong);
  } catch (e) {
    return false;
  }
}

// 确保标签页里有驱动脚本：已就绪直接返回；没注入就用 scripting 补注入
// （host_permissions 已含 chat.deepseek.com，无需整页重载）
async function ensureDriver(tabId) {
  if (await pingDriver(tabId)) return true;
  try {
    await chrome.scripting.executeScript({
      target: { tabId },
      files: [DRIVER_FILE]
    });
  } catch (e) {
    // 页面仍在加载或不是可注入页面，交给后面的轮询等待
  }
  if (await pingDriver(tabId)) return true;
  return false;
}

async function waitForDriver(tabId, timeout = DRIVER_READY_MS) {
  const deadline = Date.now() + timeout;
  while (Date.now() < deadline) {
    if (await pingDriver(tabId)) return true;
    await sleep(DRIVER_POLL_MS);
  }
  return false;
}

// 新标签页专用：不等 document_idle 自动注入，主动“探测 + 补注入”，
// 页面文档一提交（导航落地）就能把监听装好，明显早于整页加载完成。
async function waitUntilDriverReady(tabId, timeout = DRIVER_READY_MS) {
  const deadline = Date.now() + timeout;
  while (Date.now() < deadline) {
    if (await ensureDriver(tabId)) return true;
    await sleep(120);
  }
  return false;
}

// ---------- 专用后台标签页（复用 → 免去每次整页加载）----------
// 只复用“扩展自己创建的那个后台标签页”，绝不改动用户自己打开的 DeepSeek 页面。
const WORKER_TAB_KEY = "dsh_worker_tab_id";

async function getStoredWorkerTabId() {
  try {
    const d = await chrome.storage.session.get(WORKER_TAB_KEY);
    if (d && d[WORKER_TAB_KEY] != null) return d[WORKER_TAB_KEY];
  } catch (e) { /* session 存储不可用时忽略 */ }
  try {
    const d = await chrome.storage.local.get(WORKER_TAB_KEY);
    if (d && d[WORKER_TAB_KEY] != null) return d[WORKER_TAB_KEY];
  } catch (e) { /* 忽略 */ }
  return null;
}

async function storeWorkerTabId(tabId) {
  try { await chrome.storage.session.set({ [WORKER_TAB_KEY]: tabId }); } catch (e) {}
  try { await chrome.storage.local.set({ [WORKER_TAB_KEY]: tabId }); } catch (e) {}
}

// 取回可用的专用标签页；已被用户关闭 / 被回收 / 已离开 DeepSeek 则返回 null
async function getWorkerTab() {
  const stored = await getStoredWorkerTabId();
  if (stored == null) return null;
  try {
    const tab = await chrome.tabs.get(stored);
    if (!tab || tab.discarded) return null;
    if (!(tab.url || "").startsWith(DEEPSEEK_ORIGIN)) return null;
    if (await ensureDriver(tab.id)) return tab.id;
    if (await waitForDriver(tab.id, 15000)) return tab.id;
    return null;
  } catch (e) {
    return null; // 标签页已不存在
  }
}

// 解析出本次请求要用的标签页，并保证驱动就绪；失败则抛错
// 返回 { tabId, reused }：reused=true 表示复用已有对话的页面，驱动会先点“新对话”，
// 让每次提问都在干净上下文里进行——既避免历史图片干扰答案，也避免上下文越滚越长
// 导致回答越来越慢。
async function resolveTargetTab(originTabId, originUrl) {
  if (originUrl && originUrl.startsWith(DEEPSEEK_ORIGIN)) {
    // 当前页就是 DeepSeek：补注入后等它就绪（不动用户自己的对话）
    if (await ensureDriver(originTabId)) return { tabId: originTabId, reused: false };
    if (await waitForDriver(originTabId)) return { tabId: originTabId, reused: false };
    throw new Error("driver not ready");
  }

  // 复用扩展自己的后台标签页（最快路径：无需加载页面）
  const worker = await getWorkerTab();
  if (worker != null) return { tabId: worker, reused: true };

  // 兜底：后台新开一个标签页并记住它，供下次复用
  const tab = await chrome.tabs.create({ url: DEEPSEEK_ORIGIN + "/", active: false });
  await storeWorkerTabId(tab.id);
  // 不等整页 load 完成（那会白等几秒）：驱动脚本一就绪就开工，
  // 输入框何时出现由 content-deepseek.js 的 waitForInput 负责。
  if (await waitUntilDriverReady(tab.id)) return { tabId: tab.id, reused: false };
  throw new Error("tab load timeout");
}

// ---------- 同一标签页串行化（DeepSeek 一次只能跑一问）----------
const tabBusy = new Map(); // tabId -> Promise

function markTabBusy(tabId) {
  let release;
  const p = new Promise((r) => (release = r));
  tabBusy.set(tabId, p);
  return () => {
    if (tabBusy.get(tabId) === p) tabBusy.delete(tabId);
    release();
  };
}

async function waitTabIdle(tabId, timeout) {
  const busy = tabBusy.get(tabId);
  if (!busy) return;
  await Promise.race([busy, sleep(timeout)]);
}

// 点击扩展工具栏图标 = 启用/停用开关（停用后悬浮球隐藏、各功能消息被拒）
chrome.action.onClicked.addListener(() => {
  setEnabled(!extEnabled).catch(() => {});
});

// service worker 每次被唤醒都重新读一次状态，保证图标与内存一致
loadEnabled();

chrome.runtime.onInstalled.addListener(() => {
  loadEnabled();
});
chrome.runtime.onStartup.addListener(() => {
  loadEnabled();
});

// 若状态被其它地方改动（例如手动清理存储），同步内存与图标
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "local" || !changes || !changes[ENABLED_KEY]) return;
  const next = changes[ENABLED_KEY].newValue !== false;
  if (next === extEnabled) return;
  extEnabled = next;
  applyActionUi(extEnabled);
});
