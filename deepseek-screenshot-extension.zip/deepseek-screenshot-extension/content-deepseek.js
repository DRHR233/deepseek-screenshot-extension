// content-deepseek.js — DeepSeek 网页版驱动（仅 https://chat.deepseek.com/* 注入）
//
// 职责：接收 background 的 "submit" 消息 → 定位输入框 → 粘贴/上传截图 →
//       填入提示词 → 触发发送 → 监听流式回复 → 稳定后回传最终文本。
//
// ⚠️ 所有选择器集中在下方常量区，页面改版导致失效时，优先修改这里即可。
//
(() => {
  "use strict";

  if (window.__dshDeepseekInjected) return;
  window.__dshDeepseekInjected = true;

  // =====================================================================
  // 可替换选择器（页面改版失效时优先改这里）
  // =====================================================================
  const INPUT_SELECTORS = [
    "textarea#chat-input",              // DeepSeek 输入框主选择器
    "textarea[placeholder*='发送']",
    "textarea[placeholder*='Send']",
    "textarea[placeholder*='消息']",
    "textarea[placeholder*='message']",
    "textarea",                         // 任意 textarea 兜底
    "div[role='textbox'][contenteditable='true']",
    "div[role='textbox']",
    "[contenteditable='true']"
  ];

  const SEND_BUTTON_SELECTORS = [
    "button[type='submit']",
    "input[type='submit']",
    "div[role='button'][class*='send']",
    "button[class*='send']",
    "[class*='send-btn']",
    "[aria-label*='发送']",
    "[aria-label*='Send']"
  ];

  const ATTACH_INPUT_SELECTORS = [
    "input[type='file'][accept*='image']",
    "input[type='file']"
  ];

  // “新对话”按钮（复用同一个标签页时，先切到新对话，保持上下文干净 → 回答更快更准）
  // ⚠️ DeepSeek 改版后若点不到新对话，改这里即可（也可只保留按文案匹配那一路）。
  const NEW_CHAT_SELECTORS = [
    "[class*='new-chat']",
    "[class*='newChat']",
    "[data-testid*='new-chat']"
  ];
  const NEW_CHAT_LABELS = ["新对话", "新建对话", "开启新对话", "开始新对话", "New chat"];

  // 答案所在的容器/段落（实测 DeepSeek：ds-markdown 容器 + ds-markdown-paragraph 段落）
  const ANSWER_MARKDOWN_SELECTORS = [
    "[class~='ds-markdown']",              // 答案 markdown 容器（整段正文，最后一个即最新回复）
    "[class*='ds-markdown-paragraph']",    // 答案段落（实测类名，容器选择器失效时兜底）
    "[class*='markdown-body']",
    "[class*='message-content']",
    "[class*='markdown']"                  // 通用兜底
  ];

  // 思考/推理过程容器（必须排除，避免把思考过程当成答案；去掉过宽泛的 "think"）
  const THINK_SELECTORS = [
    "[class*='ds-think']",
    "[class*='ds-reasoning']",
    "[class*='ds-cot']",
    "[class*='thinking']",
    "[class*='reasoning']"
  ];
  // =====================================================================

  // ---- 提速相关参数 ----
  const STREAM_STABLE_MS = 1200; // 连续 1.2s 无变化视为流式输出稳定（越小越快，太小会截断）
  const POLL_INTERVAL_MS = 250;  // 轮询间隔（越小越快发现新内容）
  const REPLY_TIMEOUT_MS = 30000;
  const PROGRESS_EMIT_MS = 300;  // 流式增量回传节流
  const MAX_BATCH_IMAGES = 20;   // 一次最多提交的截图张数（自动模式上限，与悬浮球一致）

  // 归一化：images 数组优先，兼容旧的单图字段；最多 MAX_BATCH_IMAGES 张
  function normalizeImages(images, fallback) {
    const list = Array.isArray(images)
      ? images
      : (typeof images === "string" && images ? [images] : []);
    const out = list.filter((u) => typeof u === "string" && u.startsWith("data:image"));
    if (!out.length && typeof fallback === "string" && fallback.startsWith("data:image")) {
      out.push(fallback);
    }
    return out.slice(0, MAX_BATCH_IMAGES);
  }

  // 会显著拖慢回答的开关（DeepSeek 的“深度思考”会让回答慢好几倍）  // 若页面改版，把这里的文案改成新文案即可。
  const SLOW_TOGGLE_LABELS = ["深度思考", "智能搜索", "联网搜索"];

  function sleep(ms) {
    return new Promise((r) => setTimeout(r, ms));
  }

  function isVisible(el) {
    if (!el) return false;
    const r = el.getBoundingClientRect();
    return r.width > 0 && r.height > 0;
  }

  function isEditable(el) {
    return !!el && (el.isContentEditable || el.tagName === "TEXTAREA" || el.tagName === "INPUT");
  }

  function getInputText(el) {
    if (el.tagName === "TEXTAREA" || el.tagName === "INPUT") return el.value || "";
    return el.textContent || "";
  }

  function queryFirst(selectors, root = document) {
    for (const sel of selectors) {
      try {
        const el = root.querySelector(sel);
        if (el) return el;
      } catch (e) { /* 非法选择器跳过 */ }
    }
    return null;
  }

  // ---------- 提速：尽量关掉“深度思考 / 智能搜索” ----------
  // 只“确定是开启状态”时才点击，避免误点把本来关着的开关打开（那会更慢）。
  function isToggleOn(el) {
    try {
      if (el.getAttribute("aria-pressed") === "true") return true;
      if (el.getAttribute("aria-checked") === "true") return true;
      if (el.getAttribute("data-state") === "on") return true;
      const cls = String(el.className || "");
      if (/(^|[\s_-])(active|selected|checked|is-on|on|highlight)([\s_-]|$)/i.test(cls)) return true;
      if (el.querySelector && el.querySelector("[aria-pressed='true'],[aria-checked='true']")) return true;
    } catch (e) { /* 忽略 */ }
    return false;
  }

  // 按文案找到开关（文案必须整体相等，避免匹配到页脚那一整行免责声明）
  // 只看“叶子节点”，既便宜又准（textContent 不会把整块子树都拼进来）
  function findToggleByLabel(label) {
    let nodes = [];
    try {
      nodes = Array.from(document.querySelectorAll("button, [role='button'], [role='switch'], span, div"));
    } catch (e) {
      return null;
    }
    for (const el of nodes) {
      if (el.childElementCount > 0) continue; // 只取叶子，避免把大容器整段文本当标签
      const t = (el.textContent || "").trim();
      if (t !== label) continue;
      if (!isVisible(el)) continue;
      // 向上最多 3 层，找到真正可点击的控件
      let clickable = el;
      for (let i = 0; i < 3 && clickable && clickable !== document.body; i++) {
        if (clickable.matches && clickable.matches("button, [role='button'], [role='switch']")) break;
        clickable = clickable.parentElement;
      }
      return clickable || el;
    }
    return null;
  }

  // 返回被关掉的开关名（仅用于日志/调试）
  function disableSlowModes() {
    const turnedOff = [];
    for (const label of SLOW_TOGGLE_LABELS) {
      try {
        const el = findToggleByLabel(label);
        if (!el) continue;
        if (isToggleOn(el)) {
          el.click();
          turnedOff.push(label);
        }
      } catch (e) { /* 忽略单个开关的失败 */ }
    }
    return turnedOff;
  }

  // ---------- 复用标签页时切到“新对话”（提速 + 避免历史图片干扰）----------
  const MSG_SELECTOR =
    "[class*='ds-assistant-message-main-content'], [data-message-author-role='assistant']";

  function hasAnyMessage() {
    try {
      return document.querySelectorAll(MSG_SELECTOR).length > 0;
    } catch (e) {
      return false;
    }
  }

  function clickNewChat() {
    // A) 按已知选择器
    const el = queryFirst(NEW_CHAT_SELECTORS);
    if (el && isVisible(el)) {
      try { el.click(); return true; } catch (e) {}
    }
    // B) 按文案匹配（整体相等，避免匹配到“新对话记录”之类）
    for (const label of NEW_CHAT_LABELS) {
      const node = findToggleByLabel(label);
      if (node) {
        try { node.click(); return true; } catch (e) {}
      }
    }
    return false;
  }

  // 等消息清空（新对话切换完成），最多约 2 秒；失败也继续，不阻塞提问
  async function ensureFreshChat() {
    if (!hasAnyMessage()) return true;
    if (!clickNewChat()) return false;
    const deadline = Date.now() + 2000;
    while (Date.now() < deadline) {
      await sleep(150);
      if (!hasAnyMessage()) return true;
    }
    return false;
  }

  function dataUrlToFile(dataUrl, name = "screenshot.png") {
    const m = /^data:(.*?);base64,(.*)$/s.exec(dataUrl);
    const mime = (m && m[1]) || "image/png";
    const b64 = (m && m[2]) || (dataUrl.split(",")[1] || "");
    const bin = atob(b64);
    const arr = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
    return new File([arr], name, { type: mime });
  }

  // 让 React 受控组件正确感知 value 变化的原生 setter 技巧
  function setNativeValue(el, value) {
    const proto =
      el.tagName === "TEXTAREA" ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const desc = Object.getOwnPropertyDescriptor(proto, "value");
    if (desc && desc.set) desc.set.call(el, value);
    else el.value = value;
    el.dispatchEvent(new Event("input", { bubbles: true }));
  }

  // 找输入框：必须是“可见且可编辑”的，避免选中侧栏搜索框等隐藏元素
  function findInput() {
    const candidates = [];
    for (const sel of INPUT_SELECTORS) {
      let els = [];
      try { els = document.querySelectorAll(sel); } catch (e) { continue; }
      for (const el of els) {
        if (isEditable(el) && isVisible(el) && !candidates.includes(el)) candidates.push(el);
      }
    }
    if (!candidates.length) return null;
    // 优先命中：placeholder/aria-label/id 看起来像聊天输入框
    const preferred = candidates.find((el) =>
      /发送|Send|消息|message|提问|ask|chat|输入/i.test(
        (el.getAttribute("placeholder") || el.getAttribute("aria-label") || el.id || "")
      )
    );
    return preferred || candidates[0];
  }

  // 等待输入框出现（SPA 挂载有延迟）
  async function waitForInput(timeout = 10000) {
    const deadline = Date.now() + timeout;
    while (Date.now() < deadline) {
      const el = findInput();
      if (el) return el;
      await sleep(300);
    }
    return null;
  }

  // ---------- 图片填入（支持多张，一次只传 1 张）----------
  // 这里刻意**不再**用 “[class*='attachment'] img” 之类的附件类名来数预览图：
  // DeepSeek 附件的类名会随版本变化，匹配不到就会把“已经贴上了”误判成失败，
  // 于是又走拖拽、又走 file input，同一张图被重复上传 2~3 份。
  // 现在统一用「<img> 元素集合是否增长」作为判据，与类名无关。

  // 更稳的“有图了吗”信号：把页面里所有 <img> 元素收进一个 Set。
  // 用「元素集合增长」做判据，类名再变也能感知到新增，且不会重复贴。
  function imageElements() {
    try {
      return new Set(document.querySelectorAll("img"));
    } catch (e) {
      return new Set();
    }
  }

  function countNewImages(baselineSet) {
    let n = 0;
    for (const el of imageElements()) {
      if (!baselineSet.has(el)) n++;
    }
    return n;
  }

  function pasteFiles(input, files) {
    try {
      const dt = new DataTransfer();
      for (const f of files) dt.items.add(f);
      input.focus();
      input.dispatchEvent(new ClipboardEvent("paste", {
        bubbles: true, cancelable: true, clipboardData: dt
      }));
      return true;
    } catch (e) {
      return false;
    }
  }

  function dropFiles(input, files) {
    try {
      const dt = new DataTransfer();
      for (const f of files) dt.items.add(f);
      input.dispatchEvent(new DragEvent("drop", {
        bubbles: true, cancelable: true, dataTransfer: dt
      }));
      return true;
    } catch (e) {
      return false;
    }
  }

  // 等“页面上新增了至少 1 个 <img>”（类名无关的通用判据）
  async function waitForAnyNewImage(baselineSet, timeout) {
    const deadline = Date.now() + timeout;
    while (Date.now() < deadline) {
      if (countNewImages(baselineSet) > 0) return true;
      await sleep(120);
    }
    return countNewImages(baselineSet) > 0;
  }

  // 上传图片：**一次只上传 1 张**，逐张累积到同一个输入框，
  // 全部到位后由调用方**只发送一次**提问（多张图属于同一个问题）。
  //
  // 关键：每张图**只尝试一种方式**——一旦检测到页面上真的多出了图，就立刻收手，
  // 绝不再走后面的降级方式。否则“其实贴上了，但类名没匹配上”→ 又拖拽又文件框，
  // 同一张图会被重复传 2~3 份。
  async function attachImages(input, images) {
    const files = images.map((u, i) => dataUrlToFile(u, `screenshot-${i + 1}.png`));
    const total = files.length;
    const baselineSet = imageElements(); // 传图前页面已有的图片元素
    let attached = 0;

    for (let i = 0; i < total; i++) {
      let ok = false;

      // 方式 A：粘贴这一张
      const a0 = imageElements();
      if (pasteFiles(input, [files[i]])) {
        ok = await waitForAnyNewImage(a0, 2500);
      }

      // 方式 B：只在 A 完全没动静时才试拖拽
      if (!ok) {
        const b0 = imageElements();
        if (dropFiles(input, [files[i]])) {
          ok = await waitForAnyNewImage(b0, 2000);
        }
      }

      // 方式 C：只在 A、B 都没动静时才试隐藏 file input（清空 value 才能重复触发）
      if (!ok) {
        const c0 = imageElements();
        const fileInput = queryFirst(ATTACH_INPUT_SELECTORS);
        if (fileInput) {
          try {
            fileInput.value = "";
            const dt = new DataTransfer();
            dt.items.add(files[i]);
            fileInput.files = dt.files;
            fileInput.dispatchEvent(new Event("change", { bubbles: true }));
          } catch (e) { /* 忽略 */ }
          ok = await waitForAnyNewImage(c0, 2500);
        }
      }

      if (ok) {
        attached++;
        if (i < total - 1) await sleep(150); // 给页面一点时间消化，再传下一张
      } else if (attached === 0) {
        // 第一张就完全传不上去 → 直接失败，不要带着“没有图”的提示词去问
        return false;
      }
    }

    if (!attached) return false;

    // 收尾：再多等一会儿，避免“图还在上传中”就按了发送（上传中的预览会被丢弃）
    await sleep(300);
    return true;
  }

  // 填入提示词（多策略）
  function setPromptText(input, prompt) {
    input.focus();
    if (input.tagName === "TEXTAREA" || input.tagName === "INPUT") {
      const cur = getInputText(input).trim();
      setNativeValue(input, cur ? cur + "\n" + prompt : prompt);
      input.dispatchEvent(new Event("change", { bubbles: true }));
    } else {
      // contenteditable：execCommand → 粘贴 text/plain → 直接写 textContent
      let ok = false;
      try {
        const range = document.createRange();
        range.selectNodeContents(input);
        range.collapse(false);
        const sel = window.getSelection();
        sel.removeAllRanges();
        sel.addRange(range);
        ok = document.execCommand("insertText", false, prompt);
      } catch (e) {}
      if (!ok || !getInputText(input).includes(prompt.slice(0, 10))) {
        try {
          const dt = new DataTransfer();
          dt.setData("text/plain", prompt);
          input.dispatchEvent(new ClipboardEvent("paste", {
            bubbles: true, cancelable: true, clipboardData: dt
          }));
        } catch (e) {}
      }
      input.dispatchEvent(new InputEvent("input", {
        bubbles: true, inputType: "insertText", data: prompt
      }));
    }
  }

  function clearInput(input) {
    if (input.tagName === "TEXTAREA" || input.tagName === "INPUT") {
      setNativeValue(input, "");
    } else {
      input.textContent = "";
      input.dispatchEvent(new InputEvent("input", {
        bubbles: true, inputType: "deleteContentBackward"
      }));
    }
  }

  // 填充后校验，失败则清空重试
  async function fillPromptWithRetry(input, prompt) {
    const sig = prompt.slice(0, 10);
    for (let i = 0; i < 3; i++) {
      setPromptText(input, prompt);
      await sleep(300);
      if (getInputText(input).includes(sig)) return true;
      clearInput(input);
      await sleep(150);
    }
    return false;
  }

  function pressEnter(input) {
    const opts = {
      bubbles: true, cancelable: true,
      key: "Enter", code: "Enter", keyCode: 13, which: 13
    };
    input.dispatchEvent(new KeyboardEvent("keydown", opts));
    input.dispatchEvent(new KeyboardEvent("keypress", opts));
    input.dispatchEvent(new KeyboardEvent("keyup", opts));
  }

  async function triggerSend(input) {
    const btn = queryFirst(SEND_BUTTON_SELECTORS);
    if (btn && btn.disabled !== true && btn.getAttribute("aria-disabled") !== "true") {
      btn.click();
      await sleep(600);
    } else {
      pressEnter(input);
      await sleep(600);
    }
  }

  // ---------- 答案定位 ----------
  function isInsideThink(el) {
    let p = el;
    while (p && p !== document.body) {
      for (const sel of THINK_SELECTORS) {
        try { if (p.matches && p.matches(sel)) return true; } catch (e) {}
      }
      p = p.parentElement;
    }
    return false;
  }

  // 噪声文本判定：排除页脚免责声明、思考/搜索开关等固定 UI 文案
  function isNoiseText(t) {
    if (!t) return true;
    const s = t.trim();
    if (!s) return true;
    // 精确等于常见按钮/开关文字
    if (/^(深度思考|智能搜索|联网搜索|快速思考|搜索|DeepSeek|deepseek|发送|停止生成|复制|赞|踩)$/.test(s)) return true;
    // 含免责声明等固定文案
    if (/内容由AI生成|请仔细甄别|AI生成|免责声明|隐私|服务协议|使用条款/.test(s)) return true;
    return false;
  }

  // ---------- 文本提取：正确处理公式 / 上下标 / 换行 ----------
  // 为什么不能直接用 textContent 读数学题答案：
  //   KaTeX 一个公式会渲染成两份（.katex-mathml 给读屏用 + .katex-html 给肉眼），
  //   textContent 会把两份都拼进来，且 \frac{1}{2} 会变成 "12"、x^2 会变成 "x2"，
  //   填空/数学题就整个读错。这里改成按 DOM 结构提取，公式优先取 LaTeX 源再转可读文本。
  const MATH_SELECTOR =
    ".katex, .katex-display, .MathJax, .MathJax_Display, math, mjx-container, [data-math], [class*='katex']";

  // 常用 LaTeX 命令 → 可读符号（先长后短，避免 \le 抢先匹配 \leq）
  const TEX_SYMBOLS = [
    ["\\leqslant", "≤"], ["\\geqslant", "≥"], ["\\neq", "≠"], ["\\approx", "≈"],
    ["\\equiv", "≡"], ["\\times", "×"], ["\\cdot", "·"], ["\\div", "÷"],
    ["\\pm", "±"], ["\\mp", "∓"], ["\\leq", "≤"], ["\\le", "≤"],
    ["\\geq", "≥"], ["\\ge", "≥"], ["\\ne", "≠"], ["\\infty", "∞"],
    ["\\pi", "π"], ["\\alpha", "α"], ["\\beta", "β"], ["\\gamma", "γ"],
    ["\\delta", "δ"], ["\\theta", "θ"], ["\\lambda", "λ"], ["\\mu", "μ"],
    ["\\sigma", "σ"], ["\\phi", "φ"], ["\\omega", "ω"],
    ["\\Delta", "Δ"], ["\\Omega", "Ω"], ["\\Sigma", "Σ"],
    ["\\angle", "∠"], ["\\triangle", "△"], ["\\parallel", "∥"], ["\\perp", "⊥"],
    ["\\circ", "°"], ["\\degree", "°"], ["\\sum", "∑"], ["\\prod", "∏"],
    ["\\int", "∫"], ["\\in", "∈"], ["\\notin", "∉"], ["\\subset", "⊂"],
    ["\\cup", "∪"], ["\\cap", "∩"], ["\\emptyset", "∅"],
    ["\\forall", "∀"], ["\\exists", "∃"],
    ["\\Rightarrow", "⇒"], ["\\Leftarrow", "⇐"], ["\\Leftrightarrow", "⇔"],
    ["\\rightarrow", "→"], ["\\to", "→"], ["\\because", "∵"], ["\\therefore", "∴"],
    ["\\ldots", "…"], ["\\cdots", "…"], ["\\dots", "…"],
    ["\\%", "%"], ["\\{", "{"], ["\\}", "}"], ["\\ ", " "]
  ];

  function wrapTerm(s) {
    const t = (s || "").trim();
    // 分子/分母里有运算符时才加括号，否则 1/2 保持清爽
    return /[+\-×÷*/± ]/.test(t) ? "(" + t + ")" : t;
  }

  function texToText(tex) {
    let s = String(tex || "");
    if (!s.trim()) return "";

    // 1) 环境 / 纯排版类命令：直接去掉（\begin{cases} 之类保留内容）
    s = s.replace(/\\begin\{[^{}]*\}/g, " ").replace(/\\end\{[^{}]*\}/g, " ");
    s = s.replace(
      /\\(left|right|big|Big|bigg|Bigg|displaystyle|textstyle|limits|nolimits|mathrm|mathbf|mathit|mathsf|operatorname|textbf|text|mbox|overline|underline|hat|bar|vec|dot|ddot|widehat|widetilde)\b/g,
      ""
    );
    s = s.replace(/\\(quad|qquad|enspace|thinspace|space|,|;|:|!)/g, " ");
    // 2) 换行符：\\\\ → 换行；表格/对齐用的 & 去掉
    s = s.replace(/\\\\/g, "\n").replace(/[ \t]*&[ \t]*/g, "");

    // 3) 函数名保留成普通字母（否则会被当成未知命令删掉）
    s = s.replace(
      /\\(log|ln|lg|sin|cos|tan|cot|sec|csc|arcsin|arccos|arctan|sinh|cosh|tanh|exp|max|min|lim|mod|gcd|deg|det)(?![a-zA-Z])/g,
      "$1"
    );

    // 4) 度符号：^{\circ} / ^\circ → °
    s = s.replace(/\^\s*\{?\s*\\circ\s*\}?/g, "°");

    // 5) 结构命令逐层展开。frac/sqrt/sup/sub 可能互相嵌套
    //    （如 \frac{\sqrt{3}}{2}），因此循环到不再变化为止。
    for (let i = 0; i < 12; i++) {
      const before = s;
      s = s.replace(
        /\\[dt]?frac\s*\{([^{}]*)\}\s*\{([^{}]*)\}/g,
        (_m, x, y) => wrapTerm(x) + "/" + wrapTerm(y)
      );
      s = s.replace(
        /\\sqrt\s*\[([^{}]*)\]\s*\{([^{}]*)\}/g,
        (_m, n, x) => x.trim() + "^(1/" + n.trim() + ")"
      );
      s = s.replace(/\\sqrt\s*\{([^{}]*)\}/g, (_m, x) => "√(" + x.trim() + ")");
      s = s.replace(/\^\{([^{}]*)\}/g, (_m, p) => "^" + p.trim());
      s = s.replace(/_\{([^{}]*)\}/g, (_m, p) => "_" + p.trim());
      if (s === before) break;
    }

    // 6) 单字符上下标去掉多余空格：x^ 2 → x^2
    s = s.replace(/\^\s+([A-Za-z0-9+\-])/g, "^$1");
    s = s.replace(/_\s+([A-Za-z0-9+\-])/g, "_$1");
    // 下标后面紧跟字母数字时补空格：log_28 → log_2 8（上标不补，sin^2x 保持连写）
    s = s.replace(/(_[A-Za-z0-9])(?=[A-Za-z0-9])/g, "$1 ");

    // 7) 符号替换（长命令在前，避免 \le 抢先匹配 \leq）
    for (const [cmd, ch] of TEX_SYMBOLS) s = s.split(cmd).join(ch);

    // 8) 残留未知命令删掉；剩下的花括号只是分组用
    s = s.replace(/\\[a-zA-Z]+/g, "");
    s = s.replace(/[{}]/g, "");

    // 9) 收拾空白：行内压缩、行边界 trim、去掉空行
    s = s
      .split("\n")
      .map((line) => line.replace(/[ \t\u00a0]+/g, " ").trim())
      .filter((line) => line !== "")
      .join("\n");
    return s.trim();
  }

  // 取一段公式的文本：优先 LaTeX 源码（最准），再退回可见的 HTML 渲染层
  function mathToText(el) {
    const ann =
      el.querySelector("annotation[encoding='application/x-tex']") ||
      el.querySelector("annotation");
    if (ann) {
      const t = texToText(ann.textContent || "");
      if (t) return t;
    }
    const html = el.querySelector(".katex-html") || el;
    return (html.textContent || "").replace(/\s+/g, " ").trim();
  }

  const BLOCK_TAGS = new Set([
    "p", "div", "section", "article", "li", "ul", "ol", "tr", "table",
    "blockquote", "pre", "h1", "h2", "h3", "h4", "h5", "h6", "dd", "dt"
  ]);

  // 按 DOM 结构提取可读文本（公式、上下标、换行都还原）
  function extractText(root) {
    if (!root) return "";
    // 快路径：既没公式也没块级结构的短文本，直接 textContent
    if (!root.querySelector(MATH_SELECTOR) && !root.querySelector("sup, sub, br, table")) {
      const plain = (root.textContent || "").trim();
      return plain;
    }

    let out = "";
    const push = (s) => { out += s; };

    const walk = (node) => {
      if (node.nodeType === 3) { // 文本节点
        push(node.nodeValue || "");
        return;
      }
      if (node.nodeType !== 1) return;
      const tag = node.tagName.toLowerCase();

      // 公式整体替换，且不再下钻（否则 mathml + html 两份会重复）
      if (node.matches && node.matches(MATH_SELECTOR)) {
        const t = mathToText(node);
        if (t) push(" " + t + " ");
        return;
      }
      if (tag === "br") { push("\n"); return; }
      if (tag === "sup") { push("^"); for (const c of node.childNodes) walk(c); return; }
      if (tag === "sub") { push("_"); for (const c of node.childNodes) walk(c); return; }
      if (tag === "td" || tag === "th") {
        if (out && !out.endsWith("\n") && !out.endsWith("\t")) push("\t");
        for (const c of node.childNodes) walk(c);
        return;
      }
      if (tag === "li") {
        if (out && !out.endsWith("\n")) push("\n");
        push("· ");
        for (const c of node.childNodes) walk(c);
        return;
      }
      const isBlock = BLOCK_TAGS.has(tag);
      if (isBlock) {
        if (out && !out.endsWith("\n")) push("\n");
        for (const c of node.childNodes) walk(c);
        if (!out.endsWith("\n")) push("\n");
        return;
      }
      for (const c of node.childNodes) walk(c);
    };

    walk(root);

    return out
      .split("\n")
      .map((line) => line.replace(/[ \t\u00a0]+/g, " ").trim())
      .filter((line, i, arr) => !(line === "" && arr[i - 1] === ""))
      .join("\n")
      .trim();
  }

  // promptSig 用于排除“用户自己刚发的消息”（其文本里含提示词），
  // isInsideThink 用于排除思考过程，isNoiseText 用于排除页脚/开关等噪声。
  // 读取“最新一条 assistant 回复”的文本；
  // promptSig 用于排除“用户自己刚发的消息”（其文本里含提示词），
  // isInsideThink 用于排除思考过程，isNoiseText 用于排除页脚/开关等噪声。
  // 文本一律用 extractText() 取，公式 / 上下标 / 换行才会是正确格式。
  function readReplyText(promptSig) {
    const keepNoThink = (el) => {
      const t = extractText(el);
      if (!t) return false;
      if (isNoiseText(t)) return false;
      if (promptSig && t.includes(promptSig)) return false;
      return true;
    };

    // 方案1（首选）：assistant 消息正文容器。
    // 实测类名 ds-assistant-message-main-content（外层还有 ds-markdown 类）。
    // 这是答案本体，故不做“思考排除”，避免被思考开关的祖先类误伤。
    let els = Array.from(
      document.querySelectorAll("[class*='ds-assistant-message-main-content']")
    ).filter(keepNoThink);
    if (els.length) {
      return extractText(els[els.length - 1]);
    }

    const keep = (el) => {
      if (isInsideThink(el)) return false;
      const t = extractText(el);
      if (!t) return false;
      if (isNoiseText(t)) return false;
      if (promptSig && t.includes(promptSig)) return false;
      return true;
    };

    // 方案2：带明确 author-role 的 assistant 消息
    els = Array.from(
      document.querySelectorAll("[data-message-author-role='assistant']")
    ).filter(keep);
    if (els.length) {
      return extractText(els[els.length - 1]);
    }

    // 方案3：markdown 容器/段落，取最后一个非噪声节点
    for (const sel of ANSWER_MARKDOWN_SELECTORS) {
      els = Array.from(document.querySelectorAll(sel)).filter(keep);
      if (els.length) {
        return extractText(els[els.length - 1]);
      }
    }

    // 方案4：兜底——页面最后一个较长的非噪声文本块
    const blocks = Array.from(document.querySelectorAll("div, p, section")).filter(
      (el) => {
        const t = extractText(el);
        return (
          t.length > 10 &&
          !isNoiseText(t) &&
          !(promptSig && t.includes(promptSig)) &&
          !isInsideThink(el)
        );
      }
    );
    return blocks.length ? extractText(blocks[blocks.length - 1]) : "";
  }

  // 等待“本次发送”产生的新回复并等它稳定。
  // existingContainers 是发送前已存在的 assistant 容器集合，
  // 只读取“发送后才出现”的新容器文本，从而彻底避免读到历史会话 / 侧边栏。
  async function waitForNewReply(existingContainers, onProgress) {
    const deadline = Date.now() + REPLY_TIMEOUT_MS;
    let lastText = "";
    let lastChange = Date.now();
    let hasText = false;
    let lastEmit = 0;

    const readNewAnswer = () => {
      const els = Array.from(
        document.querySelectorAll(
          "[class*='ds-assistant-message-main-content'], [data-message-author-role='assistant']"
        )
      );
      for (const el of els) {
        if (existingContainers.has(el)) continue; // 跳过发送前已有的
        const t = extractText(el);
        if (t && !isNoiseText(t)) return t;
      }
      return "";
    };

    while (Date.now() < deadline) {
      await sleep(POLL_INTERVAL_MS);
      const text = readNewAnswer();
      if (text && text !== lastText) {
        lastText = text;
        lastChange = Date.now();
        hasText = true;
        // 边生成边回传，悬浮球可以立刻看到答案在长出来（体感更快）
        const now = Date.now();
        if (onProgress && now - lastEmit >= PROGRESS_EMIT_MS) {
          lastEmit = now;
          try { onProgress(text); } catch (e) { /* 忽略 */ }
        }
      }
      if (hasText && Date.now() - lastChange >= STREAM_STABLE_MS) {
        return lastText;
      }
    }
    if (hasText) return lastText; // 超时但有部分内容，尽量返回
    throw new Error("发送超时");
  }

  async function handleSubmit(msg) {
    const { requestId, prompt } = msg;
    // 兼容两种入口：images 数组（连续截图模式）或单个 imageDataUrl（立即回答模式）
    const images = normalizeImages(msg.images, msg.imageDataUrl);
    const reply = (type, extra) => {
      try {
        chrome.runtime.sendMessage({ type, requestId, ...extra }).catch(() => {});
      } catch (e) {}
    };

    if (!images.length) {
      reply("error", { error: "没有可发送的截图" });
      return;
    }

    try {
      // 0) 复用了带历史对话的标签页时，先切“新对话”（干净上下文 → 回答更快更准）
      if (msg.freshChat) {
        try { await ensureFreshChat(); } catch (e) { /* 切不动就继续在当前对话里问 */ }
      }

      // 1) 找输入框（等待 SPA 挂载）
      const input = await waitForInput();
      if (!input) {
        reply("error", { error: "未找到 DeepSeek 输入框" });
        return;
      }
      input.focus();

      // 提速：先关掉“深度思考 / 智能搜索”（会让回答慢好几倍）
      try { disableSlowModes(); } catch (e) {}

      // 记录发送前已存在的 assistant 容器（稍后只读“新出现”的回复）
      const existingContainers = new Set(
        document.querySelectorAll(
          "[class*='ds-assistant-message-main-content'], [data-message-author-role='assistant']"
        )
      );

      // 2) 粘贴 / 上传图片（一张或多张；成功即返回，不再空等）
      const attached = await attachImages(input, images);
      if (!attached) {
        // 图片没进输入框就发送，DeepSeek 只会看到提示词、答非所问，必须报错
        reply("error", { error: "图片上传失败，请重试" });
        return;
      }
      await sleep(150);

      // 3) 填提示词（带校验与重试）
      const filled = await fillPromptWithRetry(input, prompt);
      if (!filled) {
        reply("error", { error: "提示词填充失败" });
        return;
      }
      await sleep(150);

      // 4) 发送
      await triggerSend(input);
      await sleep(400);
      // 若输入框仍未清空，说明首次发送未生效，补一次 Enter
      if (getInputText(input).trim() !== "") pressEnter(input);

      // 5) 等待“新”回复（流式增量会通过 answer-progress 实时回传）
      const text = await waitForNewReply(existingContainers, (partial) => {
        reply("answer-progress", { text: partial });
      });
      reply("answer", { text });
    } catch (e) {
      reply("error", { error: (e && e.message) || "发送失败" });
    }
  }

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (!msg || !msg.type) return;
    if (msg.type === "ping") {
      sendResponse({ pong: true });
      return;
    }
    if (msg.type === "submit") {
      sendResponse({ ack: true });
      handleSubmit(msg);
      return;
    }
    // 超时补救：页面上（可能）已经渲染出答案了，直接读一次，不重新发送
    if (msg.type === "read-last-answer") {
      try {
        const text = readReplyText(null);
        if (text) {
          sendResponse({ ok: true, text });
        } else {
          sendResponse({ ok: false, error: "页面上还没有答案" });
        }
      } catch (e) {
        sendResponse({ ok: false, error: (e && e.message) || "读取答案失败" });
      }
      return;
    }
  });
})();
