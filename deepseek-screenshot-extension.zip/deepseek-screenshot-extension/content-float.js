// content-float.js — 悬浮球（<all_urls> 注入）
//
// 功能：右下角圆形悬浮球（Shadow DOM mode: closed）→ 点击展开面板 →
//       三种模式：立即回答（截一张直接问）/ 连续截图（先攒图再一次问）/
//       自翻页模式（每截一张就下滑一屏，最多 20 张，截完自动滚回原处并提问）。
// 悬浮球可拖拽，位置保存到 chrome.storage.local，刷新后恢复。
// 展开后的面板也可自由拖动（拖标题栏或面板空白边距），位置另存 dsh_panel_pos，
// 双击标题栏 / 点「复位」回到自动贴球位置。
//
(() => {
  "use strict";

  if (window.__dshFloatInjected) return;
  window.__dshFloatInjected = true;

  const STORAGE_KEY = "dsh_float_pos";
  const PANEL_POS_KEY = "dsh_panel_pos"; // 面板被拖动后的位置（视口坐标）；不存在=自动贴球
  const HISTORY_KEY = "dsh_answer_history";
  const HISTORY_OPEN_KEY = "dsh_history_open";
  const MAX_HISTORY = 20; // 历史答案最多保留条数
  const BALL_SIZE = 56;
  const PANEL_WIDTH = 280;
  const DRAG_THRESHOLD = 6; // 位移超过该值判定为拖拽而非点击
  const MAX_ANSWER_SHORT = 150; // 结果区默认截断长度
  const MODE_KEY = "dsh_capture_mode"; // instant=立即回答 / batch=连续截图 / auto=自翻页模式
  const AUTO_COUNT_KEY = "dsh_auto_count"; // 自翻页模式一共截几张（1~20）
  const MAX_SHOTS = 10; // 连续截图模式一次最多 10 张
  const MAX_AUTO_SHOTS = 20; // 自翻页模式一次最多 20 张
  const AUTO_SCROLL_RATIO = 0.95; // 每次下滑一屏的多少（让上一屏内容移出视野）
  const AUTO_SCROLL_WAIT = 450;   // 下滑后等页面重绘/懒加载的时间
  const ENABLED_KEY = "dsh_enabled"; // 扩展启用状态（点工具栏图标切换），缺省=启用
  const RESULT_FONT_KEY = "dsh_result_font"; // 答案框字号（px）
  const RESULT_SIZE_KEY = "dsh_result_size"; // 答案框高度（px，0=自动）
  const RESULT_FONT_MIN = 11;
  const RESULT_FONT_MAX = 22;
  const RESULT_FONT_DEFAULT = 13;
  const RESULT_MIN_HEIGHT = 44;

  // ---------- 悬浮球宿主 + Shadow DOM ----------
  const host = document.createElement("div");
  host.id = "dsh-float-host";
  host.style.cssText = "position:fixed;top:0;left:0;width:0;height:0;z-index:2147483647;";
  (document.documentElement || document.body).appendChild(host);

  const root = host.attachShadow({ mode: "closed" });

  const style = document.createElement("style");
  style.textContent = `
    * { box-sizing: border-box; margin: 0; padding: 0; }
    .wrap {
      position: fixed; z-index: 2147483647;
      font-family: -apple-system, "Segoe UI", "Microsoft YaHei", Roboto, sans-serif;
    }
    .ball {
      width: ${BALL_SIZE}px; height: ${BALL_SIZE}px;
      border-radius: 50%;
      background: linear-gradient(135deg, #4d6bfe, #7a5cff);
      color: #fff; cursor: grab;
      display: flex; align-items: center; justify-content: center;
      box-shadow: 0 4px 16px rgba(0,0,0,.30);
      user-select: none; -webkit-user-select: none;
      transition: transform .12s ease, box-shadow .12s ease;
    }
    .ball:hover { transform: scale(1.07); box-shadow: 0 6px 20px rgba(0,0,0,.36); }
    .ball.dragging { cursor: grabbing; transform: scale(1.0); }
    .ball svg { width: 28px; height: 28px; fill: #fff; display: block; pointer-events: none; }
    .panel {
      position: fixed; width: ${PANEL_WIDTH}px;
      max-height: 70vh; overflow-y: auto;
      background: #fff; color: #1f2329;
      border-radius: 12px; padding: 12px;
      box-shadow: 0 10px 30px rgba(0,0,0,.22);
      display: none; cursor: default;
      font-size: 13px; line-height: 1.5;
    }
    .panel.open { display: block; }
    .panel-title {
      font-weight: 600; font-size: 14px; margin-bottom: 8px;
      cursor: move; user-select: none; -webkit-user-select: none;
      touch-action: none;
      display: flex; align-items: center; justify-content: space-between;
      gap: 8px;
    }
    .panel-title.dragging { cursor: grabbing; }
    .panel-reset {
      border: none; background: transparent; color: #8a919e;
      font-size: 12px; cursor: pointer; padding: 2px 4px; border-radius: 4px;
      flex: none;
    }
    .panel-reset:hover { background: #f2f5ff; color: #4d6bfe; }
    .panel-title-main { display: flex; align-items: baseline; gap: 6px; min-width: 0; flex-wrap: wrap; }
    /* 作者署名 + 提示词入口放在面板最底部 */
    .author-row {
      display: flex; align-items: center; justify-content: space-between; gap: 8px;
      margin-top: 10px; padding-top: 8px;
      border-top: 1px solid #eef1f5;
      line-height: 1.4;
    }
    .prompt-btns { display: flex; align-items: center; gap: 6px; min-width: 0; flex-wrap: wrap; }
    .prompt-toggle, .prompt-restore {
      border: 1px solid #dfe3ea; background: #fff; border-radius: 999px;
      padding: 1px 8px; font-size: 11px; line-height: 16px;
      color: #6b7280; cursor: pointer; white-space: nowrap;
    }
    .prompt-toggle:hover, .prompt-restore:hover { border-color: #c7d2fe; color: #4d6bfe; background: #f2f5ff; }
    .prompt-toggle.active { border-color: #4d6bfe; color: #4d6bfe; background: #f2f5ff; }
    .prompt-restore:hover { border-color: #fbd5b5; color: #d97706; background: #fff7ed; }
    .panel-author {
      font-weight: 400; font-size: 11px; color: #8a919e;
      text-decoration: none; white-space: nowrap; cursor: pointer;
      margin-left: auto; /* 靠右 */
    }
    .panel-author:hover { color: #4d6bfe; text-decoration: underline; }

    /* 提示词编辑器（默认收起） */
    .prompt-editor { display: none; margin-top: 8px; }
    .prompt-editor.open { display: block; }
    .prompt-head {
      display: flex; align-items: baseline; justify-content: space-between;
      gap: 6px; margin-bottom: 4px;
    }
    .prompt-label { font-size: 12px; color: #4b5563; }
    .prompt-tip { font-size: 10px; color: #9aa0aa; }
    .prompt-text {
      width: 100%; box-sizing: border-box; resize: vertical;
      min-height: 84px; max-height: 220px;
      padding: 6px 8px; border: 1px solid #dfe3ea; border-radius: 8px;
      font-family: inherit; font-size: 12px; line-height: 1.5; color: #1f2329;
      background: #fff;
    }
    .prompt-text:focus { outline: none; border-color: #4d6bfe; }
    .prompt-actions { display: flex; gap: 6px; margin-top: 6px; }
    .btn.mini {
      width: auto; padding: 5px 10px; font-size: 12px;
      margin-bottom: 0; border-radius: 6px;
    }
    .btn {
      width: 100%; padding: 9px 0; border: none; border-radius: 8px;
      background: #4d6bfe; color: #fff; font-size: 14px; cursor: pointer;
      margin-bottom: 8px;
    }
    .btn:hover { background: #3f5bf0; }
    .btn:disabled { background: #b6c0e0; cursor: not-allowed; }
    .btn.secondary {
      background: #fff; color: #4d6bfe; border: 1px solid #c7d2fe;
    }
    .btn.secondary:hover { background: #f2f5ff; }
    .btn-row { display: flex; gap: 6px; }
    .btn-row .btn { flex: 1; }
    .btn-row.batch-only { display: none; }
    .btn-row.batch-only.show { display: flex; }
    .btn.resend-btn {
      margin-top: 2px;
      font-size: 13px;
    }
undefined
    .modes { display: flex; gap: 6px; margin-bottom: 8px; }
    /* 第二行模式按钮：只放一个，让它占满整行，并收紧与上一行的间距 */
    .mode {
      flex: 1; padding: 6px 2px; border: 1px solid #dfe3ea; border-radius: 8px;
      background: #fff; color: #4b5563; font-size: 12px; cursor: pointer;
      white-space: nowrap;
    }
    .mode.active {
      border-color: #4d6bfe; color: #4d6bfe; background: #f2f5ff; font-weight: 600;
    }
    .mode:disabled { opacity: .55; cursor: not-allowed; }
    .auto-row {
      display: none; align-items: center; flex-wrap: wrap; gap: 6px;
      margin: -2px 0 8px; font-size: 12px; color: #6b7280;
    }
    .auto-row.open { display: flex; }
    .auto-label { flex: none; color: #8a919e; }
    .auto-label.grow { flex: 1 1 100%; color: #8a919e; font-size: 11px; }
    .auto-count {
      width: 46px; padding: 3px 4px; text-align: center;
      border: 1px solid #dfe3ea; border-radius: 6px;
      font-size: 12px; color: #1f2329; background: #fff;
    }
    .auto-count:focus { outline: none; border-color: #4d6bfe; }
    .shots-head {
      display: none; align-items: center; justify-content: space-between;
      margin: 2px 0 6px; font-size: 12px; color: #6b7280;
    }
    .shots-head.open { display: flex; }
    .shots-hint { color: #8a919e; font-size: 11px; }
    .shots {
      display: none; grid-template-columns: repeat(4, 1fr);
      gap: 6px; margin-bottom: 8px;
    }
    .shots.open { display: grid; }
    .shot {
      position: relative; aspect-ratio: 1 / 1;
      border: 1px solid #e6e8ec; border-radius: 6px; overflow: hidden;
      background: #f6f7f9;
    }
    .shot img { width: 100%; height: 100%; object-fit: cover; display: block; }
    .shot-del {
      position: absolute; top: 0; right: 0; width: 16px; height: 16px;
      border: none; border-radius: 0 0 0 6px; padding: 0;
      background: rgba(0,0,0,.55); color: #fff;
      font-size: 11px; line-height: 16px; text-align: center; cursor: pointer;
    }
    .result {
      min-height: 44px; max-height: 60vh; overflow: auto;
      background: #f6f7f9; border: 1px solid #e6e8ec;
      border-radius: 8px; padding: 8px;
      white-space: pre-wrap; word-break: break-word;
      color: #1f2329;
      font-size: 13px; line-height: 1.5;
      resize: vertical; /* 右下角可拖动改高度 */
    }
    .result-tools {
      display: flex; align-items: center; gap: 4px;
      margin: 2px 0 4px; font-size: 11px; color: #8a919e;
    }
    .result-tools .rt-label { margin-right: 2px; }
    .result-tools button {
      border: 1px solid #dfe3ea; background: #fff; border-radius: 6px;
      padding: 0 6px; height: 20px; line-height: 18px;
      font-size: 11px; color: #4b5563; cursor: pointer;
    }
    .result-tools button:hover:not(:disabled) { border-color: #4d6bfe; color: #4d6bfe; }
    .result-tools button:disabled { opacity: .45; cursor: not-allowed; }
    .result-tools .rt-size { min-width: 30px; text-align: center; color: #6b7280; }
    .result-tools .rt-reset { margin-left: auto; }
    .result-wrap { display: flex; align-items: flex-start; gap: 6px; }
    .result-wrap .result { flex: 1 1 auto; min-width: 0; }
    .result-refresh {
      flex: 0 0 auto; width: 34px; height: 34px; padding: 0;
      border: 1px solid #e6e8ec; border-radius: 8px; background: #fff;
      color: #4d6bfe; font-size: 15px; line-height: 1; cursor: pointer;
      display: flex; align-items: center; justify-content: center;
      transition: background .15s, border-color .15s;
    }
    .result-refresh:hover { background: #f2f5ff; border-color: #c7d2fe; }
    .result-refresh:disabled { opacity: .55; cursor: not-allowed; }
    .result-refresh[hidden] { display: none; }
    .result.expandable { cursor: pointer; }
    .result.error { color: #d33; background: #fdeeee; border-color: #f3c2c2; }
    .result.loading { color: #888; }
    .history-head {
      display: flex; align-items: center; justify-content: space-between;
      margin: 10px 0 6px; font-size: 12px; color: #6b7280;
    }
    .history-title {
      display: inline-flex; align-items: center; gap: 4px;
      cursor: pointer; user-select: none; -webkit-user-select: none;
    }
    .history-title:hover { color: #4d6bfe; }
    .history-arrow {
      display: inline-block; font-size: 10px;
      transition: transform .15s ease;
    }
    .history-title.open .history-arrow { transform: rotate(90deg); }
    .history-count { color: #9aa0aa; }
    .history-clear {
      border: none; background: none; padding: 0; cursor: pointer;
      font-size: 12px; color: #4d6bfe;
    }
    .history-clear:hover { text-decoration: underline; }
    .history-list {
      display: none;
      max-height: 150px; overflow-y: auto;
      border-top: 1px solid #e6e8ec; padding-top: 6px;
    }
    .history-list.open { display: block; }
    .history-item {
      padding: 6px 8px; border-radius: 6px; margin-bottom: 4px;
      background: #f6f7f9; cursor: pointer;
    }
    .history-item:hover { background: #eef1f7; }
    .history-time { font-size: 11px; color: #8a919e; margin-bottom: 2px; }
    .history-text {
      font-size: 12px; color: #1f2329;
      white-space: pre-wrap; word-break: break-word;
    }
    .history-empty { font-size: 12px; color: #9aa0aa; padding: 4px 2px; }
  `;
  root.appendChild(style);

  const wrap = document.createElement("div");
  wrap.className = "wrap";

  const ball = document.createElement("div");
  ball.className = "ball";
  ball.title = "DeepSeek 截图提问";
  ball.innerHTML = cameraIcon();

  const panel = document.createElement("div");
  panel.className = "panel";
  panel.innerHTML = `
    <div class="panel-title">
      <span class="panel-title-main">
        <span>DeepSeek 截图提问</span>
      </span>
      <button class="panel-reset" type="button" title="回到悬浮球旁边的默认位置">复位</button>
    </div>
    <div class="modes">
      <button class="mode active" type="button" data-mode="instant">立即回答</button>
      <button class="mode" type="button" data-mode="batch">连续截图</button>
      <button class="mode" type="button" data-mode="auto">自翻页模式</button>
    </div>
    <div class="auto-row">
      <span class="auto-label">共截</span>
      <input class="auto-count" type="number" min="1" max="${MAX_AUTO_SHOTS}" step="1" value="5" />
      <span class="auto-label">张（1~${MAX_AUTO_SHOTS}）每张自动下滑一屏</span>
    </div>
    <button class="btn main-btn" type="button">📷 截图并提问</button>
    <button class="btn secondary resend-btn" type="button" title="把刚刚上传过的图片再发一次">🔁 重新上传</button>
    <div class="shots-head">
      <span>已截 <span class="shots-count">0</span>/<span class="shots-limit">${MAX_SHOTS}</span> 张</span>
      <span class="shots-hint">最多一次 <span class="shots-limit">${MAX_SHOTS}</span> 张</span>
    </div>
    <div class="shots"></div>
    <div class="btn-row batch-only">
      <button class="btn secondary ask-btn" type="button">✅ 发送提问</button>
      <button class="btn secondary clear-shots-btn" type="button">清空截图</button>
    </div>
    <div class="result-tools">
      <span class="rt-label">答案字号</span>
      <button class="rt-font-minus" type="button" title="字号变小">A－</button>
      <span class="rt-size">13</span>
      <button class="rt-font-plus" type="button" title="字号变大">A＋</button>
      <button class="rt-reset" type="button" title="字号和高度都恢复默认（答案框右下角可拖动改高度）">重置</button>
    </div>
    <div class="result-wrap">
      <div class="result">等待提问…</div>
      <button class="result-refresh" type="button" title="重新读取页面上的答案（不重新发送）" hidden>🔄</button>
    </div>
    <div class="history-head">
      <span class="history-title" role="button" tabindex="0" aria-expanded="false">
        <span class="history-arrow">▶</span>
        <span>历史答案</span>
        <span class="history-count"></span>
      </span>
      <button class="history-clear" type="button">清空</button>
    </div>
    <div class="history-list"><div class="history-empty">暂无历史</div></div>
    <div class="prompt-editor">
      <div class="prompt-head">
        <span class="prompt-label">发送给 DeepSeek 的提示词</span>
        <span class="prompt-tip">改完点保存；留空则恢复默认</span>
      </div>
      <textarea class="prompt-text" spellcheck="false" rows="5"></textarea>
      <div class="prompt-actions">
        <button class="btn mini prompt-save" type="button">保存</button>
        <button class="btn mini secondary prompt-reset" type="button">恢复默认</button>
        <button class="btn mini secondary prompt-cancel" type="button">取消</button>
      </div>
    </div>
    <div class="author-row">
      <div class="prompt-btns">
        <button class="prompt-toggle" type="button" title="查看 / 修改发送给 DeepSeek 的提示词">✏️ 修改提示词</button>
        <button class="prompt-restore" type="button" title="一键恢复为扩展内置的默认提示词">↺ 恢复默认</button>
      </div>
      <a class="panel-author" href="https://space.bilibili.com/1373775117?spm_id_from=333.1007.0.0"
         target="_blank" rel="noopener noreferrer"
         title="by@b站杜韧浩然 — 点击前往 B 站主页">by@b站杜韧浩然</a>
    </div>
  `;

  wrap.appendChild(ball);
  wrap.appendChild(panel);
  root.appendChild(wrap);

  const btn = panel.querySelector(".main-btn");
  const resendBtnEl = panel.querySelector(".resend-btn");
  const resultEl = panel.querySelector(".result");
  const resultRefreshEl = panel.querySelector(".result-refresh");
  const rtFontMinusEl = panel.querySelector(".rt-font-minus");
  const rtFontPlusEl = panel.querySelector(".rt-font-plus");
  const rtSizeEl = panel.querySelector(".rt-size");
  const rtResetEl = panel.querySelector(".rt-reset");
  // 模式按钮统一收集一次（用 querySelectorAll，避免漏掉后加的模式）
  const modeBtns = Array.from(panel.querySelectorAll(".mode"));
  const shotsEl = panel.querySelector(".shots");
  const shotsHeadEl = panel.querySelector(".shots-head");
  const shotsCountEl = panel.querySelector(".shots-count");
  const shotsLimitEls = panel.querySelectorAll(".shots-limit");
  const askBtnEl = panel.querySelector(".ask-btn");
  const clearShotsBtnEl = panel.querySelector(".clear-shots-btn");
  const batchOnlyEls = panel.querySelectorAll(".batch-only");
  const historyListEl = panel.querySelector(".history-list");
  const historyTitleEl = panel.querySelector(".history-title");
  const historyCountEl = panel.querySelector(".history-count");
  const historyClearEl = panel.querySelector(".history-clear");
  const promptToggleEl = panel.querySelector(".prompt-toggle");
  const promptRestoreEl = panel.querySelector(".prompt-restore");
  const promptEditorEl = panel.querySelector(".prompt-editor");
  const promptTextEl = panel.querySelector(".prompt-text");
  const promptSaveEl = panel.querySelector(".prompt-save");
  const promptResetEl = panel.querySelector(".prompt-reset");
  const promptCancelEl = panel.querySelector(".prompt-cancel");
  const panelTitleEl = panel.querySelector(".panel-title");
  const autoRowEl = panel.querySelector(".auto-row");
  const autoCountEl = panel.querySelector(".auto-count");
  let fullAnswer = "";

  function cameraIcon() {
    return '<svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">' +
      '<path d="M12 15.2a3.2 3.2 0 1 0 0-6.4 3.2 3.2 0 0 0 0 6.4z"/>' +
      '<path d="M9 3 7.17 5H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V7c0-1.1-.9-2-2-2h-3.17L15 3H9zm3 15a5 5 0 1 1 0-10 5 5 0 0 1 0 10z"/>' +
      '</svg>';
  }

  // ---------- 位置（默认右下角）----------
  let pos = {
    x: Math.max(8, window.innerWidth - BALL_SIZE - 20),
    y: Math.max(8, window.innerHeight - BALL_SIZE - 140)
  };

  function clamp(v, min, max) {
    return Math.min(Math.max(v, min), max);
  }

  function applyPosition() {
    wrap.style.left = pos.x + "px";
    wrap.style.top = pos.y + "px";
  }

  function savePosition() {
    try {
      chrome.storage.local.set({ [STORAGE_KEY]: { x: pos.x, y: pos.y } });
    } catch (e) { /* 忽略存储异常 */ }
  }

  applyPosition();
  try {
    chrome.storage.local.get([STORAGE_KEY, PANEL_POS_KEY], (data) => {
      const saved = data && data[STORAGE_KEY];
      if (saved && typeof saved.x === "number" && typeof saved.y === "number") {
        pos.x = clamp(saved.x, 0, Math.max(0, window.innerWidth - BALL_SIZE));
        pos.y = clamp(saved.y, 0, Math.max(0, window.innerHeight - BALL_SIZE));
      }
      applyPosition();
      const savedPanel = data && data[PANEL_POS_KEY];
      if (savedPanel && typeof savedPanel.x === "number" && typeof savedPanel.y === "number") {
        panelPos = clampPanelPos(savedPanel.x, savedPanel.y);
        if (panel.classList.contains("open")) positionPanel();
      }
    });
  } catch (e) {
    applyPosition();
  }

  // ---------- 拖拽 vs 点击 ----------
  let dragState = null;

  ball.addEventListener("pointerdown", (e) => {
    dragState = {
      id: e.pointerId,
      sx: e.clientX,
      sy: e.clientY,
      bx: pos.x,
      by: pos.y,
      moved: false
    };
    try { ball.setPointerCapture(e.pointerId); } catch (err) {}
    ball.classList.add("dragging");
  });

  ball.addEventListener("pointermove", (e) => {
    if (!dragState || e.pointerId !== dragState.id) return;
    const dx = e.clientX - dragState.sx;
    const dy = e.clientY - dragState.sy;
    if (!dragState.moved && Math.hypot(dx, dy) < DRAG_THRESHOLD) return;
    dragState.moved = true;
    pos.x = clamp(dragState.bx + dx, 0, Math.max(0, window.innerWidth - BALL_SIZE));
    pos.y = clamp(dragState.by + dy, 0, Math.max(0, window.innerHeight - BALL_SIZE));
    applyPosition();
    // 自翻页模式下（面板没被手动拖过）让面板跟着球一起走
    if (!panelPos && panel.classList.contains("open")) positionPanel();
  });

  ball.addEventListener("pointerup", (e) => {
    if (!dragState || e.pointerId !== dragState.id) return;
    const moved = dragState.moved;
    dragState = null;
    ball.classList.remove("dragging");
    if (moved) savePosition();
    else togglePanel();
  });

  ball.addEventListener("pointercancel", () => {
    dragState = null;
    ball.classList.remove("dragging");
  });

  // ---------- 面板开合 ----------
  // panelPos = 用户拖动面板后的视口坐标；null 表示“自动贴在球旁边”
  let panelPos = null;

  function savePanelPos() {
    try {
      if (panelPos) chrome.storage.local.set({ [PANEL_POS_KEY]: panelPos });
      else chrome.storage.local.remove(PANEL_POS_KEY);
    } catch (e) { /* 忽略存储异常 */ }
  }

  function clampPanelPos(x, y) {
    const maxX = Math.max(8, window.innerWidth - PANEL_WIDTH - 8);
    const maxY = Math.max(8, window.innerHeight - 80); // 至少留 80px 在视口里
    return { x: clamp(x, 8, maxX), y: clamp(y, 8, maxY) };
  }

  function positionPanel() {
    // 1) 用户手动拖过 → 用保存的位置（再次夹紧，防止窗口变小后跑到视口外）
    if (panelPos) {
      const p = clampPanelPos(panelPos.x, panelPos.y);
      panelPos = p;
      panel.style.left = p.x + "px";
      panel.style.top = p.y + "px";
      panel.style.right = "auto";
      panel.style.bottom = "auto";
      panel.style.maxHeight = Math.max(180, window.innerHeight - p.y - 8) + "px";
      return;
    }

    // 2) 自翻页模式：默认贴在球旁边
    // 水平：面板右缘对齐球右缘；球太靠左则改为左缘对齐，并夹在视口内
    let left = pos.x + BALL_SIZE - PANEL_WIDTH;
    if (pos.x < PANEL_WIDTH - BALL_SIZE) left = pos.x;
    left = clamp(left, 8, Math.max(8, window.innerWidth - PANEL_WIDTH - 8));
    panel.style.left = left + "px";
    panel.style.right = "auto";

    // 垂直：先在球下方试排，量出内容自然高度，再决定是否翻到上方，
    // 并按可用空间设置 maxHeight，保证历史区始终能滚动看到而不是被裁掉。
    panel.style.top = pos.y + BALL_SIZE + 8 + "px";
    panel.style.bottom = "auto";
    panel.style.maxHeight = "none";
    const natural = panel.scrollHeight || panel.offsetHeight;

    const spaceBelow = window.innerHeight - (pos.y + BALL_SIZE + 8) - 8;
    const spaceAbove = pos.y - 8 - 8;
    const flip = natural > spaceBelow && spaceAbove > spaceBelow;

    if (flip) {
      panel.style.top = "auto";
      panel.style.bottom = window.innerHeight - pos.y + 8 + "px";
      panel.style.maxHeight = Math.max(180, spaceAbove) + "px";
    } else {
      panel.style.top = pos.y + BALL_SIZE + 8 + "px";
      panel.style.bottom = "auto";
      panel.style.maxHeight = Math.max(180, spaceBelow) + "px";
    }
  }

  // ---------- 面板拖拽（拖标题栏或面板空白处）----------
  let panelDrag = null;

  function onPanelDown(e) {
    // 拖拽手柄：标题栏，或面板自身的空白区域（按钮/结果区/历史区里不拖）
    const target = e.target;
    if (target && target.closest && target.closest(".panel-reset")) return; // 复位按钮交给 click
    // 作者链接交给浏览器自己处理（原生 <a> + target=_blank），别进入拖拽，
    // 否则 setPointerCapture 会把后续 pointerup/click 抢过来，链接点不动
    if (target && target.closest && target.closest(".panel-author")) return;
    const isTitle = panelTitleEl && panelTitleEl.contains(target);
    const isBlank = target === panel;
    if (!isTitle && !isBlank) return;
    if (e.button !== 0 && e.pointerType === "mouse") return;

    const rect = panel.getBoundingClientRect();
    panelDrag = {
      id: e.pointerId,
      sx: e.clientX,
      sy: e.clientY,
      px: rect.left,
      py: rect.top,
      moved: false
    };
    // 注意：这里先不设置 panelPos —— 单纯点一下标题栏不应该让面板“脱离”悬浮球，
    // 真正开始移动时才转为手动定位（见 onPanelMove）。
    try { panel.setPointerCapture(e.pointerId); } catch (err) {}
    if (isTitle && panelTitleEl) panelTitleEl.classList.add("dragging");
    // 注意：这里不 preventDefault —— 否则会抑制后续的 click/dblclick
    //（标题栏双击复位要能触发），文字选中已由 user-select:none 屏蔽。
  }

  function onPanelMove(e) {
    if (!panelDrag || e.pointerId !== panelDrag.id) return;
    const dx = e.clientX - panelDrag.sx;
    const dy = e.clientY - panelDrag.sy;
    if (!panelDrag.moved && Math.hypot(dx, dy) < 3) return;
    panelDrag.moved = true;
    const p = clampPanelPos(panelDrag.px + dx, panelDrag.py + dy);
    panelPos = p;
    panel.style.left = p.x + "px";
    panel.style.top = p.y + "px";
    panel.style.right = "auto";
    panel.style.bottom = "auto";
    panel.style.maxHeight = Math.max(180, window.innerHeight - p.y - 8) + "px";
    e.preventDefault();
  }

  function onPanelUp(e) {
    if (!panelDrag || e.pointerId !== panelDrag.id) return;
    const moved = panelDrag.moved;
    panelDrag = null;
    if (panelTitleEl) panelTitleEl.classList.remove("dragging");
    if (moved) savePanelPos();
  }

  panel.addEventListener("pointerdown", onPanelDown);
  panel.addEventListener("pointermove", onPanelMove);
  panel.addEventListener("pointerup", onPanelUp);
  panel.addEventListener("pointercancel", () => {
    panelDrag = null;
    if (panelTitleEl) panelTitleEl.classList.remove("dragging");
  });

  // 复位：双击标题栏，或点右上角「复位」，回到自动贴球位置
  function resetPanelPos() {
    panelPos = null;
    savePanelPos();
    positionPanel();
  }
  panel.addEventListener("dblclick", (e) => {
    // 双击标题栏空白处 = 复位；但别把作者链接的双击也当成复位
    if (e.target && e.target.closest && e.target.closest(".panel-author")) return;
    if (panelTitleEl && panelTitleEl.contains(e.target)) resetPanelPos();
  });
  const panelResetEl = panel.querySelector(".panel-reset");
  if (panelResetEl) {
    panelResetEl.addEventListener("click", (e) => {
      e.stopPropagation();
      resetPanelPos();
    });
  }

  // 窗口尺寸变化：把手动位置重新夹进视口，自翻页模式跟着球重排
  window.addEventListener("resize", () => {
    if (panel.classList.contains("open")) positionPanel();
  });

  function togglePanel() {
    const willOpen = !panel.classList.contains("open");
    panel.classList.toggle("open", willOpen);
    if (willOpen) {
      positionPanel();
      updateShotsUI();
      refreshResendInfo();
      if (!warmed) {
        warmed = true;
        prewarm();
      }
    }
  }
  let warmed = false;

  // ---------- 结果展示 ----------
  // 是否显示“重新读取答案”按钮：只在超时这类“答案可能已经生成、只是没收到”的场景出现
  function updateResultRefresh(isError, text) {
    if (!resultRefreshEl) return;
    const timedOut = !!isError && /超时|timeout/i.test(text || "");
    resultRefreshEl.hidden = !timedOut;
    resultRefreshEl.disabled = false;
  }

  // 截图失败时补一句可操作的建议：
  // captureVisibleTab 报的 "activeTab permission is not in effect" 通常是
  // 用户刚启用/停用过扩展、activeTab 授权过期，用工具栏图标关一下再开一下即可恢复。
  const CAPTURE_FAIL_HINT = "在工具栏关闭后再开启后可用";
  const TIMEOUT_HINT = "若 DS 正常，点击右侧 🔄 刷新按钮重新读取答案";

  function withCaptureHint(text, isError) {
    const t = (text || "").trim();
    if (!isError) return t;
    if (!/截图失败/.test(t)) return t;
    if (t.includes(CAPTURE_FAIL_HINT)) return t; // 避免重复追加
    // 提示紧跟在“截图失败”后面；原始错误详情挪到括号里，保留排查信息
    const detail = t
      .replace(/^截图失败[，,]?\s*(请重试)?\s*/, "")
      .replace(/^[（(]/, "")
      .replace(/[）)]$/, "")
      .trim();
    const head = "截图失败，" + CAPTURE_FAIL_HINT;
    return detail ? head + "\n（详情：" + detail + "）" : head;
  }

  // 发送超时：答案很可能已经在 DeepSeek 页面上生成好了，提示去点结果区右侧的 🔄
  function withTimeoutHint(text, isError) {
    const t = (text || "").trim();
    if (!isError) return t;
    if (!/超时|timeout/i.test(t)) return t;
    if (t.includes(TIMEOUT_HINT)) return t; // 避免重复追加
    // 只替换开头的“发送超时”，后面的进度信息（如“已有部分内容”）保留
    if (t.startsWith("超时") || t.startsWith("发送超时")) {
      const rest = t.replace(/^(?:发送)?超时[，,]?\s*/, "").trim();
      return "发送超时，" + TIMEOUT_HINT + (rest ? "\n" + rest : "");
    }
    return t + "\n" + TIMEOUT_HINT;
  }

  function showResult(text, isError) {
    fullAnswer = withTimeoutHint(withCaptureHint(text, isError), isError);
    resultEl.classList.remove("loading");
    resultEl.classList.toggle("error", !!isError);
    resultEl.classList.toggle("expandable", fullAnswer.length > MAX_ANSWER_SHORT);
    updateResultRefresh(isError, fullAnswer);
    if (!fullAnswer) {
      resultEl.textContent = "（无内容）";
      return;
    }
    resultEl.textContent = fullAnswer.length > MAX_ANSWER_SHORT
      ? fullAnswer.slice(0, MAX_ANSWER_SHORT) + "…"
      : fullAnswer;
    resultEl.title = fullAnswer.length > MAX_ANSWER_SHORT ? "点击展开完整答案" : "";
  }

  // 流式增量：先实时显示，最终 answer 到来后再定稿（体感更快）
  function showStreaming(text) {
    if (!text) return;
    fullAnswer = text;
    resultEl.classList.remove("error", "expandable");
    resultEl.classList.add("loading");
    updateResultRefresh(false, "");
    resultEl.textContent = text.length > MAX_ANSWER_SHORT
      ? text.slice(0, MAX_ANSWER_SHORT) + "…"
      : text;
    resultEl.title = "";
  }

  let skipResultClick = false; // 拖动答案框右下角改高度后，抑制随之而来的 click

  resultEl.addEventListener("click", () => {
    // 刚拖过右下角把手调高度：这次 click 是拖拽的副产物，不要切换展开/折叠
    if (skipResultClick) {
      skipResultClick = false;
      return;
    }
    if (!fullAnswer) return;
    if (resultEl.textContent.length < fullAnswer.length) {
      resultEl.textContent = fullAnswer; // 展开
    } else {
      resultEl.textContent = fullAnswer.length > MAX_ANSWER_SHORT
        ? fullAnswer.slice(0, MAX_ANSWER_SHORT) + "…"
        : fullAnswer; // 折叠
    }
  });

  // ---------- 答案框：字号可调 + 高度可拖 ----------
  // 字号：面板上的 A－ / A＋ 调，范围 11~22px
  // 高度：直接拖答案框右下角（CSS resize: vertical），拖完记住
  let resultFont = RESULT_FONT_DEFAULT;
  let resultHeight = 0; // 0 = 自动高度

  function applyResultFont(size, save) {
    resultFont = clamp(Math.round(size), RESULT_FONT_MIN, RESULT_FONT_MAX);
    resultEl.style.fontSize = resultFont + "px";
    if (rtSizeEl) rtSizeEl.textContent = String(resultFont);
    if (rtFontMinusEl) rtFontMinusEl.disabled = resultFont <= RESULT_FONT_MIN;
    if (rtFontPlusEl) rtFontPlusEl.disabled = resultFont >= RESULT_FONT_MAX;
    if (save) {
      try { chrome.storage.local.set({ [RESULT_FONT_KEY]: resultFont }); } catch (e) {}
    }
    if (panel.classList.contains("open")) positionPanel();
  }

  function applyResultHeight(px, save) {
    resultHeight = px > 0 ? Math.max(RESULT_MIN_HEIGHT, Math.round(px)) : 0;
    if (resultHeight) resultEl.style.height = resultHeight + "px";
    else resultEl.style.removeProperty("height");
    if (save) {
      try { chrome.storage.local.set({ [RESULT_SIZE_KEY]: resultHeight }); } catch (e) {}
    }
    if (panel.classList.contains("open")) positionPanel();
  }

  if (rtFontMinusEl) {
    rtFontMinusEl.addEventListener("click", (ev) => {
      ev.stopPropagation();
      applyResultFont(resultFont - 1, true);
    });
  }
  if (rtFontPlusEl) {
    rtFontPlusEl.addEventListener("click", (ev) => {
      ev.stopPropagation();
      applyResultFont(resultFont + 1, true);
    });
  }
  if (rtResetEl) {
    rtResetEl.addEventListener("click", (ev) => {
      ev.stopPropagation();
      applyResultFont(RESULT_FONT_DEFAULT, true);
      applyResultHeight(0, true);
    });
  }

  // 只有用户拖动右下角把手时才记住高度。
  // 不能用 ResizeObserver 存高度：答案文本长短变化也会触发尺寸变化，
  // 那样会把「短答案时的矮高度」误存成固定高度，长答案就只能滚动。
  (function watchManualResize() {
    const HANDLE = 20; // 右下角把手的感应范围（px）
    let dragging = false;
    resultEl.addEventListener("mousedown", (ev) => {
      const r = resultEl.getBoundingClientRect();
      dragging = ev.clientX >= r.right - HANDLE && ev.clientY >= r.bottom - HANDLE;
    });
    document.addEventListener("mouseup", () => {
      if (!dragging) return;
      dragging = false;
      skipResultClick = true; // 拖完会紧跟一次 click，别让它把答案折起来
      const h = Math.round(resultEl.getBoundingClientRect().height);
      if (!h) return;
      resultHeight = h;
      try { chrome.storage.local.set({ [RESULT_SIZE_KEY]: resultHeight }); } catch (e) {}
      if (panel.classList.contains("open")) positionPanel();
    });
  })();

  // ---------- 重新读取答案（超时后的补救按钮）----------
  if (resultRefreshEl) {
    resultRefreshEl.addEventListener("click", (ev) => {
      ev.stopPropagation(); // 别触发结果区的“展开/折叠”
      resultRefreshEl.disabled = true;
      resultEl.classList.add("loading");
      try {
        chrome.runtime.sendMessage({ type: "reread-answer" }, (resp) => {
          if (chrome.runtime.lastError) {
            showResult("重新读取失败（" + chrome.runtime.lastError.message + "）", true);
            return;
          }
          if (resp && resp.ok && resp.text) {
            showResult(resp.text, false);
            addHistoryEntry(resp.text);
            if (panel.classList.contains("open")) positionPanel();
          } else {
            // 页面上确实还没有答案：保留“重新读取”按钮，方便再点一次
            const msg = (resp && resp.error) || "页面上还没有答案，请稍后再试";
            showResult(msg, true);
            if (resultRefreshEl) {
              resultRefreshEl.hidden = false;
              resultRefreshEl.disabled = false;
            }
          }
        });
      } catch (e) {
        showResult("重新读取失败", true);
      }
    });
  }

undefined  // ---------- 历史答案 ----------
  let history = []; // [{ text, time }]

  function formatTime(ts) {
    try {
      const d = new Date(ts);
      const pad = (n) => String(n).padStart(2, "0");
      return (
        d.getFullYear() + "-" + pad(d.getMonth() + 1) + "-" + pad(d.getDate()) +
        " " + pad(d.getHours()) + ":" + pad(d.getMinutes()) + ":" + pad(d.getSeconds())
      );
    } catch (e) {
      return "";
    }
  }

  function renderHistory() {
    if (!historyListEl) return;
    if (historyCountEl) {
      historyCountEl.textContent = history.length ? `(${history.length})` : "";
    }
    historyListEl.textContent = "";
    if (!history.length) {
      const empty = document.createElement("div");
      empty.className = "history-empty";
      empty.textContent = "暂无历史";
      historyListEl.appendChild(empty);
      return;
    }
    history.forEach((item) => {
      const row = document.createElement("div");
      row.className = "history-item";

      const timeEl = document.createElement("div");
      timeEl.className = "history-time";
      timeEl.textContent = formatTime(item.time);

      const textEl = document.createElement("div");
      textEl.className = "history-text";
      const t = item.text || "";
      textEl.textContent = t.length > MAX_ANSWER_SHORT ? t.slice(0, MAX_ANSWER_SHORT) + "…" : t;

      row.appendChild(timeEl);
      row.appendChild(textEl);
      row.title = "点击回显这条答案";
      row.addEventListener("click", () => {
        showResult(t, false);
      });
      historyListEl.appendChild(row);
    });
  }

  function persistHistory() {
    try {
      chrome.storage.local.set({ [HISTORY_KEY]: history });
    } catch (e) { /* 忽略存储异常 */ }
  }

  function addHistoryEntry(text) {
    if (!text) return;
    // 与最近一条相同则不重复记录
    if (history.length && history[0].text === text) return;
    history.unshift({ text, time: Date.now() });
    if (history.length > MAX_HISTORY) history = history.slice(0, MAX_HISTORY);
    persistHistory();
    renderHistory();
  }

  try {
    chrome.storage.local.get(HISTORY_KEY, (data) => {
      const saved = data && data[HISTORY_KEY];
      if (Array.isArray(saved)) {
        history = saved
          .filter((it) => it && typeof it.text === "string" && it.text)
          .slice(0, MAX_HISTORY);
      }
      renderHistory();
    });
  } catch (e) {
    renderHistory();
  }

  // ---------- 历史区折叠 ----------
  // 默认展开，用户手动折叠后记住状态（存 chrome.storage.local）。
  let historyOpen = true;

  function setHistoryOpen(open, save) {
    historyOpen = !!open;
    if (historyListEl) historyListEl.classList.toggle("open", historyOpen);
    if (historyTitleEl) {
      historyTitleEl.classList.toggle("open", historyOpen);
      historyTitleEl.setAttribute("aria-expanded", historyOpen ? "true" : "false");
      historyTitleEl.title = historyOpen ? "点击折叠历史答案" : "点击展开历史答案";
    }
    if (save) {
      try {
        chrome.storage.local.set({ [HISTORY_OPEN_KEY]: historyOpen });
      } catch (e) { /* 忽略存储异常 */ }
    }
    if (historyOpen && panel.classList.contains("open")) positionPanel();
  }

  if (historyTitleEl) {
    const toggle = () => setHistoryOpen(!historyOpen, true);
    historyTitleEl.addEventListener("click", toggle);
    historyTitleEl.addEventListener("keydown", (e) => {
      if (e.key === "Enter" || e.key === " ") {
        e.preventDefault();
        toggle();
      }
    });
  }

  try {
    chrome.storage.local.get(HISTORY_OPEN_KEY, (data) => {
      const saved = data && data[HISTORY_OPEN_KEY];
      setHistoryOpen(typeof saved === "boolean" ? saved : true, false);
    });
  } catch (e) {
    setHistoryOpen(true, false);
  }

  if (historyClearEl) {
    historyClearEl.addEventListener("click", () => {
      history = [];
      persistHistory();
      renderHistory();
    });
  }

  // ---------- 提示词：查看 / 修改 / 保存 ----------
  let promptLoaded = false;

  function setPromptEditorOpen(open) {
    if (!promptEditorEl) return;
    promptEditorEl.classList.toggle("open", !!open);
    if (promptToggleEl) {
      promptToggleEl.classList.toggle("active", !!open);
      promptToggleEl.textContent = open ? "✏️ 收起提示词" : "✏️ 修改提示词";
    }
    if (open && !promptLoaded) loadPrompt();
    if (panel.classList.contains("open")) positionPanel();
  }

  function fillPromptText(text) {
    if (!promptTextEl) return;
    promptTextEl.value = typeof text === "string" ? text : "";
  }

  function loadPrompt() {
    try {
      chrome.runtime.sendMessage({ type: "get-prompt" }, (resp) => {
        if (chrome.runtime.lastError) return;
        if (resp && resp.ok) {
          fillPromptText(resp.text);
          promptLoaded = true;
        }
      });
    } catch (e) { /* 忽略 */ }
  }

  if (promptToggleEl) {
    promptToggleEl.addEventListener("click", (ev) => {
      ev.stopPropagation();
      setPromptEditorOpen(!promptEditorEl.classList.contains("open"));
    });
  }

  if (promptSaveEl) {
    promptSaveEl.addEventListener("click", (ev) => {
      ev.stopPropagation();
      const text = promptTextEl ? promptTextEl.value : "";
      try {
        chrome.runtime.sendMessage({ type: "save-prompt", text }, (resp) => {
          if (chrome.runtime.lastError) {
            showResult("保存提示词失败：" + chrome.runtime.lastError.message, true);
            return;
          }
          if (resp && resp.ok) {
            fillPromptText(resp.text);
            promptLoaded = true;
            showResult("提示词已保存，下次提问生效。", false);
            setPromptEditorOpen(false);
          } else {
            showResult((resp && resp.error) || "保存提示词失败", true);
          }
        });
      } catch (e) {
        showResult("保存提示词失败", true);
      }
    });
  }

  // 恢复默认（编辑框内的按钮 与 底部的常驻按钮 共用同一套逻辑）
  function doResetPrompt() {
    try {
      chrome.runtime.sendMessage({ type: "reset-prompt" }, (resp) => {
        if (chrome.runtime.lastError) {
          showResult("恢复默认失败：" + chrome.runtime.lastError.message, true);
          return;
        }
        if (resp && resp.ok) {
          fillPromptText(resp.text);
          promptLoaded = true;
          showResult("已恢复默认提示词。", false);
          if (panel.classList.contains("open")) positionPanel();
        } else {
          showResult((resp && resp.error) || "恢复默认失败", true);
        }
      });
    } catch (e) {
      showResult("恢复默认失败", true);
    }
  }

  if (promptResetEl) {
    promptResetEl.addEventListener("click", (ev) => {
      ev.stopPropagation();
      doResetPrompt();
    });
  }

  // 底部常驻的「↺ 恢复默认」：不用展开编辑框也能一键还原，并同步编辑框内容
  if (promptRestoreEl) {
    promptRestoreEl.addEventListener("click", (ev) => {
      ev.stopPropagation();
      doResetPrompt();
    });
  }

  if (promptCancelEl) {
    promptCancelEl.addEventListener("click", (ev) => {
      ev.stopPropagation();
      // 取消：丢弃未保存的改动，重新读一次已保存的值
      promptLoaded = false;
      loadPrompt();
      setPromptEditorOpen(false);
    });
  }

  // 在编辑框里按 Esc 直接收起
  if (promptTextEl) {
    promptTextEl.addEventListener("keydown", (ev) => {
      ev.stopPropagation();
      if (ev.key === "Escape") {
        ev.preventDefault();
        promptLoaded = false;
        loadPrompt();
        setPromptEditorOpen(false);
      }
    });
  }

  // ---------- 截图模式 + 连续截图暂存 ----------
  let mode = "instant"; // instant=立即回答；batch=连续截图；auto=自翻页模式
  let shots = [];       // [{ id, url }] 连续/自翻页模式暂存的截图（data URL，只在内存里，不落盘）
  let autoRunning = false; // 自翻页模式正在跑，防止重复点击

  function isBatch() {
    return mode === "batch";
  }

  function isAuto() {
    return mode === "auto";
  }

  // 当前模式下的截图上限
  function shotLimit() {
    return isAuto() ? MAX_AUTO_SHOTS : MAX_SHOTS;
  }

  // 读取自翻页模式的面板输入（夹到 1~MAX_AUTO_SHOTS）
  function getAutoCount() {
    let n = parseInt(autoCountEl && autoCountEl.value, 10);
    if (!Number.isFinite(n)) n = 5;
    n = Math.min(Math.max(n, 1), MAX_AUTO_SHOTS);
    if (autoCountEl) autoCountEl.value = String(n);
    return n;
  }

  function updateShotsUI() {
    const n = shots.length;
    const limit = shotLimit();
    if (shotsCountEl) shotsCountEl.textContent = String(n);
    // 上限随模式变化：连续截图 10 张、自翻页模式 20 张
    for (const el of shotsLimitEls) el.textContent = String(limit);
    // 连续截图 / 自翻页模式都展示已截缩略图（自翻页模式边截边显示，便于确认拍到了什么）
    if (shotsHeadEl) shotsHeadEl.classList.toggle("open", isBatch() || isAuto());
    if (shotsEl) shotsEl.classList.toggle("open", (isBatch() || isAuto()) && n > 0);
    for (const el of batchOnlyEls) el.classList.toggle("show", isBatch());
    if (autoRowEl) autoRowEl.classList.toggle("open", isAuto());
    // 自翻页截取进行中不允许切模式/改张数，避免半路换逻辑
    for (const el of modeBtns) el.disabled = autoRunning;
    if (autoCountEl) autoCountEl.disabled = autoRunning;
    if (askBtnEl) askBtnEl.disabled = !isBatch() || n === 0;
    if (clearShotsBtnEl) clearShotsBtnEl.disabled = !isBatch() || n === 0;
    if (isAuto()) {
      btn.textContent = autoRunning
        ? "⏹ 自翻页截取中…"
        : "📷 自翻页截取";
      btn.disabled = autoRunning;
undefined    } else if (isBatch()) {
      btn.textContent = n >= limit ? `📷 已达上限 ${limit} 张` : `📷 截图（${n}/${limit}）`;
      btn.disabled = n >= limit;
    } else {
      btn.textContent = "📷 截图并提问";
      btn.disabled = false;
    }
  }

  function renderShots() {
    if (!shotsEl) return;
    shotsEl.textContent = "";
    for (const shot of shots) {
      const item = document.createElement("div");
      item.className = "shot";
      const img = document.createElement("img");
      img.src = shot.url;
      img.alt = "截图";
      const del = document.createElement("button");
      del.className = "shot-del";
      del.type = "button";
      del.textContent = "×";
      del.title = "删除这张";
      del.addEventListener("click", (ev) => {
        ev.stopPropagation();
        shots = shots.filter((s) => s.id !== shot.id);
        renderShots();
        updateShotsUI();
        if (panel.classList.contains("open")) positionPanel();
      });
      item.appendChild(img);
      item.appendChild(del);
      shotsEl.appendChild(item);
    }
    updateShotsUI();
  }

  function addShot(url) {
    if (shots.length >= shotLimit()) return false;
    shots.push({ id: Date.now() + "-" + Math.random().toString(36).slice(2, 8), url });
    renderShots();
    if (panel.classList.contains("open")) positionPanel();
    return true;
  }

  function clearShots() {
    shots = [];
    renderShots();
    updateShotsUI();
    if (panel.classList.contains("open")) positionPanel();
  }

  function setMode(next, silent) {
    mode =
      next === "batch" ? "batch"
      : next === "auto" ? "auto"
      : next === "page" ? "page"
      : "instant";
    for (const el of modeBtns) {
      el.classList.toggle("active", el.dataset.mode === mode);
    }
    updateShotsUI();
    if (!silent) {
      if (isAuto()) {
        showResult(
          `自翻页模式：点一下会连续截 ${getAutoCount()} 张（先截当前画面，再自动下滑一屏继续截），` +
          `截完自动滚回原处并发送提问。`,
          false
        );
undefined      } else if (isBatch()) {
        showResult(
          shots.length
            ? `已存 ${shots.length} 张截图，可继续截图，或点「发送提问」一起提问。`
            : `连续截图模式：先截多张（最多 ${MAX_SHOTS} 张），再点「发送提问」。`,
          false
        );
      } else {
        showResult("立即回答模式：点一下就截图并直接提问。", false);
      }
    }
    if (panel.classList.contains("open")) positionPanel();
    try { chrome.storage.local.set({ [MODE_KEY]: mode }); } catch (e) {}
  }

  // 点击委托挂在面板上，两行按钮都能响应
  panel.addEventListener("click", (ev) => {
    const target = ev.target.closest ? ev.target.closest(".mode") : null;
    if (target && target.dataset.mode) setMode(target.dataset.mode);
  });

  // 预热：面板打开时让后台把 DeepSeek 标签页备好，点截图时几乎不用等
  function prewarm() {
    try {
      chrome.runtime.sendMessage({ type: "prewarm" }, () => void chrome.runtime.lastError);
    } catch (e) { /* 忽略 */ }
  }

  // 截图（连续模式用）：只截图并暂存，不提问
  function captureOne() {
    btn.disabled = true;
    resultEl.classList.remove("error", "expandable");
    resultEl.classList.add("loading");
    resultEl.textContent = "截图中…";

    const finish = () => {
      btn.disabled = false;
      updateShotsUI();
      if (panel.classList.contains("open")) positionPanel();
    };

    try {
      chrome.runtime.sendMessage({ type: "capture-only" }, (resp) => {
        if (chrome.runtime.lastError) {
          finish();
          showResult("截图失败，请重试（" + chrome.runtime.lastError.message + "）", true);
          return;
        }
        if (!resp || !resp.ok) {
          finish();
          showResult((resp && resp.error) || "截图失败，请重试", true);
          return;
        }
        resultEl.classList.remove("loading");
        addShot(resp.imageDataUrl);
        finish();
        const n = shots.length;
        resultEl.textContent = n >= MAX_SHOTS
          ? `已存 ${n} 张（达上限 ${MAX_SHOTS} 张），请点「发送提问」或先删掉几张。`
          : `已存 ${n} 张，可继续截图；点「发送提问」一次性提交。`;
      });
    } catch (e) {
      finish();
      showResult("截图失败，请重试", true);
    }
  }

  // ---------- 自翻页模式：连续截图（每张下滑一屏）+ 自动提问 ----------
  function sleep(ms) {
    return new Promise((r) => setTimeout(r, ms));
  }

  // 只截一张（Promise 版 capture-only）
  function captureOnce() {
    return new Promise((resolve) => {
      try {
        chrome.runtime.sendMessage({ type: "capture-only" }, (resp) => {
          if (chrome.runtime.lastError) {
            resolve({ ok: false, error: chrome.runtime.lastError.message || "截图失败" });
            return;
          }
          if (!resp || !resp.ok || !resp.imageDataUrl) {
            resolve({ ok: false, error: (resp && resp.error) || "截图失败，请重试" });
            return;
          }
          resolve({ ok: true, url: resp.imageDataUrl });
        });
      } catch (e) {
        resolve({ ok: false, error: "截图失败，请重试" });
      }
    });
  }

  // 截图瞬间把悬浮球和面板藏起来，避免自己被截进画面；截完立刻恢复
  async function captureWithoutSelf() {
    const prevWrap = wrap.style.visibility;
    const prevPanel = panel.style.visibility;
    wrap.style.visibility = "hidden";
    panel.style.visibility = "hidden";
    await sleep(80); // 等浏览器完成一次重绘再截
    const res = await captureOnce();
    wrap.style.visibility = prevWrap;
    panel.style.visibility = prevPanel;
    await sleep(40);
    return res;
  }

  // 往下翻一屏：让上一屏内容移出视野后再截下一张
  function scrollOneScreen() {
    const before = window.scrollY || document.documentElement.scrollTop || 0;
    const step = Math.max(120, Math.round(window.innerHeight * AUTO_SCROLL_RATIO));

    // 1) 常规页面：滚 window
    try { window.scrollBy({ top: step, left: 0, behavior: "auto" }); } catch (e) {}

    let after = window.scrollY || document.documentElement.scrollTop || 0;
    if (Math.abs(after - before) >= 8) return true;

    // 2) 页面自己滚动的容器（DeepSeek 之类把滚动放在内层 div 上）
    const candidates = document.querySelectorAll(
      "main, [class*='scroll'], [class*='container'], [style*='overflow']"
    );
    for (const el of candidates) {
      if (!el || el.scrollHeight <= el.clientHeight + 8) continue;
      const b = el.scrollTop;
      try { el.scrollBy({ top: step, left: 0, behavior: "auto" }); } catch (e) {
        el.scrollTop = b + step;
      }
      if (Math.abs(el.scrollTop - b) >= 8) return true;
    }

    // 3) 兜底：直接滚文档根
    const root = document.scrollingElement || document.documentElement;
    if (root) {
      const b = root.scrollTop;
      try { root.scrollTop = b + step; } catch (e) {}
      if (Math.abs(root.scrollTop - b) >= 8) return true;
    }

    after = window.scrollY || document.documentElement.scrollTop || 0;
    return Math.abs(after - before) >= 8;
  }

  // 记录当前滚动位置（window + 内层可滚动容器），截完图后原样滚回去
  function snapshotScroll() {
    const snap = {
      winX: window.scrollX || 0,
      winY: window.scrollY || document.documentElement.scrollTop || 0,
      roots: []
    };
    try {
      const els = document.querySelectorAll("*");
      for (const el of els) {
        if (el.scrollTop || el.scrollLeft) {
          snap.roots.push({ el, top: el.scrollTop, left: el.scrollLeft });
        }
      }
    } catch (e) { /* 忽略 */ }
    return snap;
  }

  function restoreScroll(snap) {
    if (!snap) return;
    try { window.scrollTo({ top: snap.winY, left: snap.winX, behavior: "auto" }); } catch (e) {}
    for (const r of snap.roots) {
      try {
        r.el.scrollTop = r.top;
        r.el.scrollLeft = r.left;
      } catch (e) { /* 元素可能已被移除 */ }
    }
    const root = document.scrollingElement || document.documentElement;
    if (root && Math.abs(root.scrollTop - snap.winY) >= 1) {
      try { root.scrollTop = snap.winY; } catch (e) {}
    }
  }

  async function runAuto() {
    if (autoRunning) return;
    const total = getAutoCount();
    autoRunning = true;
    updateShotsUI();
    clearShots(); // 自翻页模式总是从空白开始，避免上一轮残留混进来
    resultEl.classList.remove("error", "expandable");
    resultEl.classList.add("loading");

    // 截图前记住当前位置，拍完（不管成功、滚到底还是中途失败）都滚回原处
    const scrollSnap = snapshotScroll();
    let scrolledOut = false;   // 是否因为滚不动了而提前收工
    let firstShotError = null; // 第一张就失败时的错误文案

    try {
      // ---------- 阶段一：连拍（每拍一张下滑一屏）----------
      try {
        for (let i = 1; i <= total; i++) {
          resultEl.textContent = `自翻页截取中…（第 ${i}/${total} 张）`;
          const shot = await captureWithoutSelf();
          if (!shot.ok) {
            if (i === 1) {
              firstShotError = shot.error || "截图失败，请重试";
              break;
            }
            break; // 第一张之后失败就不要再翻滚了
          }
          addShot(shot.url);

          if (i < total) {
            const moved = scrollOneScreen();
            await sleep(AUTO_SCROLL_WAIT);
            if (!moved) {
              scrolledOut = true;
              break; // 已经到底，再截就是重复画面
            }
          }
        }
      } finally {
        // 关键：拍完立刻滚回起点，早于发送提问——用户不必等答案出来才回位
        restoreScroll(scrollSnap);
        await sleep(60); // 让回滚先完成重绘，再继续下面的文案/发送
      }

      // ---------- 阶段二：把这批图一次性问出去 ----------
      if (firstShotError) {
        showResult(firstShotError, true);
        return;
      }

      const n = shots.length;
      if (!n) {
        showResult("截图失败，请重试", true);
        return;
      }

      resultEl.textContent =
        n < total && scrolledOut
          ? `已截 ${n} 张（页面已到底），正在发送提问…`
          : `已截 ${n} 张，正在发送提问…`;
      await askShotsAsync();
    } catch (e) {
      showResult("截图失败，请重试", true);
    } finally {
      autoRunning = false;
      resultEl.classList.remove("loading");
      updateShotsUI();
      if (panel.classList.contains("open")) positionPanel();
    }
  }

  function askShots() {
    if (!shots.length) {
      showResult("还没有截图，请先截图", true);
      return;
    }
    askShotsAsync();
  }

  // Promise 版：自翻页模式要等“发送完成”后再收尾
  function askShotsAsync() {
    return new Promise((resolve) => {
      if (!shots.length) {
        showResult("还没有截图，请先截图", true);
        resolve(false);
        return;
      }
      resultEl.classList.remove("error", "expandable");
      resultEl.classList.add("loading");
      resultEl.textContent = `已发送 ${shots.length} 张截图（同一张提问里逐张上传），等待回答…`;
      if (askBtnEl) askBtnEl.disabled = true;
      btn.disabled = true;

      try {
        chrome.runtime.sendMessage({ type: "ask", images: shots.map((s) => s.url) }, (resp) => {
          if (askBtnEl) askBtnEl.disabled = false;
          updateShotsUI(); // 失败时保持“已达上限”等正确状态
          if (chrome.runtime.lastError) {
            showResult("发送失败（" + chrome.runtime.lastError.message + "）", true);
            resolve(false);
            return;
          }
          if (!resp || !resp.ok) {
            showResult((resp && resp.error) || "发送失败", true);
            resolve(false);
            return;
          }
          // 已成功交给 DeepSeek，清空暂存，方便下一轮连续截图
          clearShots();
          resolve(true);
        });
      } catch (e) {
        if (askBtnEl) askBtnEl.disabled = false;
        updateShotsUI();
        showResult("发送失败", true);
        resolve(false);
      }
    });
  }

undefined  // ---------- 重新上传：把刚刚上传过的图片再发一次 ----------
  let resendCount = 0;

  function updateResendBtn() {
    if (!resendBtnEl) return;
    resendBtnEl.textContent = resendCount
      ? `🔁 重新上传（${resendCount} 张）`
      : "🔁 重新上传";
    resendBtnEl.disabled = resendCount === 0;
    resendBtnEl.title = resendCount
      ? `把刚刚上传过的 ${resendCount} 张图片原样再发一次`
      : "还没有上传过的图片，先截一张图";
  }

  function refreshResendInfo() {
    try {
      chrome.runtime.sendMessage({ type: "resend-info" }, (resp) => {
        if (chrome.runtime.lastError) return;
        resendCount = (resp && resp.count) || 0;
        updateResendBtn();
      });
    } catch (e) { /* 忽略 */ }
  }

  function resendLast() {
    if (resendBtnEl) resendBtnEl.disabled = true;
    resultEl.classList.remove("error", "expandable");
    resultEl.classList.add("loading");
    resultEl.textContent = "重新上传中…";
    try {
      chrome.runtime.sendMessage({ type: "resend-last" }, (resp) => {
        if (chrome.runtime.lastError) {
          updateResendBtn();
          showResult("重新上传失败（" + chrome.runtime.lastError.message + "）", true);
          return;
        }
        if (!resp || !resp.ok) {
          updateResendBtn();
          showResult((resp && resp.error) || "重新上传失败", true);
          return;
        }
        resendCount = resp.count || resendCount;
        updateResendBtn();
        resultEl.classList.remove("loading");
        resultEl.textContent = `已重新上传 ${resendCount} 张图片，等待回答…`;
      });
    } catch (e) {
      updateResendBtn();
      showResult("重新上传失败", true);
    }
  }

  if (resendBtnEl) {
    resendBtnEl.disabled = true;
    resendBtnEl.addEventListener("click", resendLast);
  }

  if (askBtnEl) askBtnEl.addEventListener("click", askShots);
  if (clearShotsBtnEl) {
    clearShotsBtnEl.addEventListener("click", () => {
      clearShots();
      showResult("已清空截图", false);
    });
  }

  // ---------- 消息 ----------
  btn.addEventListener("click", () => {
    if (isAuto()) {
      runAuto();
      return;
    }

    if (isBatch()) {
      if (shots.length >= MAX_SHOTS) {
        showResult(`最多一次 ${MAX_SHOTS} 张，请先点「发送提问」或删掉几张再截。`, true);
        return;
      }
      captureOne();
      return;
    }

    // 立即回答模式：截图 + 直接提问
    btn.disabled = true;
    resultEl.classList.remove("error", "expandable");
    resultEl.classList.add("loading");
    resultEl.textContent = "截图中…";

    try {
      chrome.runtime.sendMessage({ type: "capture-and-ask" }, (resp) => {
        btn.disabled = false;
        if (chrome.runtime.lastError) {
          showResult("截图失败，请重试（" + chrome.runtime.lastError.message + "）", true);
          return;
        }
        if (resp && resp.ok) {
          resultEl.classList.remove("loading");
          resultEl.textContent = "已发送，等待回答…";
          refreshResendInfo(); // 这张图会被暂存，按钮随之可用
        } else {
          showResult((resp && resp.error) || "截图失败，请重试", true);
        }
      });
    } catch (e) {
      btn.disabled = false;
      showResult("截图失败，请重试", true);
    }
  });

  chrome.runtime.onMessage.addListener((msg) => {
    if (!msg || !msg.type) return;
    if (msg.type === "answer") {
      const text = msg.text || "";
      showResult(text, false);
      addHistoryEntry(text);
      refreshResendInfo(); // 暂存的就是这一批，按钮上的张数同步一下
      if (panel.classList.contains("open")) positionPanel();
    } else if (msg.type === "answer-progress") {
      // 流式增量（整批图只有一个答案，直接显示生成中的文本）
      showStreaming(msg.text || "");
    } else if (msg.type === "error") {
      showResult(msg.error || "操作失败", true);
      updateResendBtn(); // 失败后暂存仍在，按钮恢复可用
    }
  });

  // ---------- 初始化：恢复上次使用的模式、自翻页张数、答案框字号与高度 ----------
  try {
    chrome.storage.local.get(
      [MODE_KEY, AUTO_COUNT_KEY, RESULT_FONT_KEY, RESULT_SIZE_KEY],
      (data) => {
        const saved = data && data[MODE_KEY];
        const savedCount = data && data[AUTO_COUNT_KEY];
        const savedFont = data && data[RESULT_FONT_KEY];
        const savedSize = data && data[RESULT_SIZE_KEY];
        if (autoCountEl && typeof savedCount === "number") {
          autoCountEl.value = String(clamp(savedCount, 1, MAX_AUTO_SHOTS));
        }
        if (typeof savedFont === "number") applyResultFont(savedFont, false);
        if (typeof savedSize === "number") applyResultHeight(savedSize, false);
        setMode(
          saved === "batch" ? "batch"
          : saved === "auto" ? "auto"
          : "instant",
          true
        );
      }
    );
  } catch (e) {
    setMode("instant", true);
  }

  if (autoCountEl) {
    autoCountEl.addEventListener("change", () => {
      const n = getAutoCount();
      try { chrome.storage.local.set({ [AUTO_COUNT_KEY]: n }); } catch (e) {}
      updateShotsUI();
      if (panel.classList.contains("open")) positionPanel();
    });
    // 回车直接开始，输入框里按回车不要触发页面别的行为
    autoCountEl.addEventListener("keydown", (ev) => {
      ev.stopPropagation();
      if (ev.key === "Enter") {
        ev.preventDefault();
        autoCountEl.blur();
        if (isAuto()) runAuto();
      }
    });
    autoCountEl.addEventListener("click", (ev) => ev.stopPropagation());
  }

  updateShotsUI();

  // ---------- 启用 / 停用（点扩展工具栏图标切换）----------
  // 停用时把整个 wrap 隐藏（球和面板一起消失），再点图标即恢复。
  function applyEnabled(on) {
    wrap.style.display = on ? "" : "none";
    if (!on && panel.classList.contains("open")) {
      panel.classList.remove("open");
      ball.classList.remove("active");
    }
  }

  try {
    chrome.storage.local.get(ENABLED_KEY, (data) => {
      applyEnabled(!data || data[ENABLED_KEY] !== false);
    });
  } catch (e) {
    applyEnabled(true);
  }

  // 工具栏图标切换后，所有已打开页面的悬浮球实时跟着显示/隐藏
  try {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== "local" || !changes || !changes[ENABLED_KEY]) return;
      applyEnabled(changes[ENABLED_KEY].newValue !== false);
    });
  } catch (e) { /* 忽略 */ }
})();
